from templib import rf,wf,createF; 

import json;

from var import*#ndic bdic books

bible=rf("/storage/emulated/0/Task/bible.txt")#bible file

jsonbible={};

k=0;#catalyst

for i in range( len(books)):

	start="\n1:1 "	x=bible.index(start,k)

	k=x+1

	y=bible.index(start,k)

	print(x,y)

	

	jsonbible[books[i]]=bible[x:y]

jsonbible [books[38]]=jsonbible[books[38]].replace(jsonbible [books[38]][jsonbible [books[38]].index("***"):],"")

print (jsonbible [books[0]])

jbible=json.dumps(jsonbible,indent=4)

#createF("/storage/emulated/0/Task/task1.txt",jbible)
