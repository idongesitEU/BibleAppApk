#remove horrible text 

from templib import rf,createF,wf

from json import loads,dumps

from var import *

jbible=rf("/storage/emulated/0/Task/task1.txt")

bible=loads(jbible)

#print(repr(bible[books[36]]))

for book in books:

	try:		ln="\n"*5;

		ind=bible[book].index(ln);

		outcast=bible[book][ind:]

		print(outcast)

		bible[book]=bible[book].replace(outcast,"")

	except:

		break;

		

jsonbible=dumps(bible,indent=4)

#createF("/storage/emulated/0/Task/task2.txt", jsonbible)
