 import sys

def indexx(main,sub,c):

	try:

		return main.index(sub,c)

	except:

		return -1

	#c=catalyst

def indexOf(mainString,subString,sv):

	rv=-1;#return value

	if sv>len(mainString):

		return rv

	if sv==0:

		try:

			trv=mainString.index(subString);

			rv=trv;

			return rv;

		except:

			return rv;

	else:

		try:

			rsv=mainString [:sv]

			tstr=mainString[sv::];

			trv=tstr.index(subString);

			rv=trv+len(rsv)

			return rv;

		except:

			return rv

		

#seperator 

		 			 			 			 			 			 	

def rpUs(arr,str,ust):#array to string

	i=0;

	sv=0

	while i<len(arr):

		if arr[i]=="Micah":

			ims=indexOf(str,"Micah",sv)

			sv=ims

			tempstr=str[ims:ims+70]

			ts=tempstr

			str=str.replace(tempstr,"{} {}".format(ust,ts))

			

		elif arr[i]=="Zephaniah":

			ims=indexOf(str,"Zephaniah",sv)

			

			sv=ims

			tempstr=str[ims:ims+100]

			ts=tempstr

			str=str.replace(tempstr,"{} {}".format(ust,ts))

			

		else:

			mst="{}|1:1".format(arr[i])#mock string

			

			ims=indexOf(str,mst,sv)

			

			sv=ims

			tempstr=str[ims:ims+70]

			ts=tempstr

			str=str.replace(tempstr,"{} {}".format(ust,ts))

			

		

		i+=1#increment I by 1

		

	return str

	

	

	

#seperator 

def replaceTest(arr,str):

	i=0;j=0;k=0;#varriables

	n=1;#number varriable

	subString=" | Holy Bible | Old Testament | King James | Book "#substring

	en="\n"

	while i<len(arr):

		j=0;

		tst=arr[i].upper();#current string

		mstr=f"""{en}{tst}{subString}{n}"""

		ind=indexOf(str,mstr,k);

		

		ls=len(mstr);#length of mainString 

		

		tind1=indexOf(str,en,ind+ls)

		tind2=indexOf (str,en,1+tind1)

		nst=str[tind1:tind2];#additional string

		

		mstr+=nst;

		

		str=str.replace(mstr,"")

		

		

		k=ind

		

		i+=1;n+=1;

		

	return str

	

	

	

#seperator

def mainArgs(arr,str,rpv):

	k=0

	bs="\n"

	for book in arr:

		if book==arr[9]:

			tstr='\n\n\n\x0cSamual II\n Samuel II|1:1 Now it came to '

	

			ind=indexOf (str,tstr,k);k=ind

			

			str=str.replace(tstr,f"÷+*€&@$? {tstr}")

		elif book==arr[12]:

			tstr='\n\n\n\x0c Chronicles-I|1:1 A'

			ind=indexOf (str,tstr,k);k=ind

			

			str=str.replace(tstr,f"÷+*€&@$? {tstr}")

		elif book==arr[13]:

			tstr='\n\n\x0c Chronicles-II|1:1 And '

			ind=indexOf (str,tstr,k);k=ind

			

			str=str.replace(tstr,f"÷+*€&@$? {tstr}")

		elif book==arr[21]:

			tstr="\n\n\n\x0cSong ofSolomon\n Song of Solomon|1:1 The song of songs, which is Solomon's.\nS"

			ind=indexOf (str,tstr,k);k=ind

			

			str=str.replace(tstr,f"÷+*€&@$? {tstr}")

		

		elif book==arr[32]:

			tstr='\n\n\x0c Micah\nMicha|1:1 The word of the LORD that came to Micah the Morast'

			ind=indexOf (str,tstr,k);k=ind

		elif book==arr[35]:

			tstr='.\n\n\n\x0cZephania\nZephania|1:1 The word of the LORD which came unto  Ze'

			

			str=str.replace(tstr,f"÷+*€&@$? {tstr}")

			ind=indexOf (str,tstr,k);k=ind

		else:

			tstr="{}\n {}|1:1 ".format(book,book)

			

			str=str.replace(tstr,f"÷+*€&@$? {tstr}")

			ind=indexOf(str,tstr,k);k=ind;

			

	return str

#divider

#Divider

#divider 

#Read file

def rf(fn):

	opf=open(fn,"r");

	ns=opf.read();

	opf.close();

	return ns;

	

#divider #dividet

##########$$$$$$########################

#Write file

def wf(fn,str):

	cf(fn)#clear file

	#fn=file name

	opf=open(fn,"w");

	opf.write(str);

	opf.close();

	

	

#######create file###########

def createF(fn,inpu):

	fil=open(fn,"w+")

	wf(fn,inpu);

	

###############$$$###########

#divider

#clear an annoying file 

def cf(fn):

	opf=open(fn,"w");

	opf.write("");

	opf.close();

	

	

##############################

#####divider

#replace string index

def rsi(string,index,value):

	#string is the main string

	#index is the index you want to replace 

	#value is what you want to replace the index with 

	lst=list(string)

	lst[index]=value

	newString="".join(lst)

	return newString 

	

#add string index from first item

def asi(string,value):

	lst=list(string);#string to list

	tstore=lst[0];#first item in list

	nv=value+tstore

	lst[0]=nv

	

	newString="".join(lst)

	return newString;
