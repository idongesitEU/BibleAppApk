bdic={'GENESIS': '50', 'EXODUS': '40', 'LEVITICUS': '27', 'NUMBERS': '36', 'DEUTERONOMY': '34', 'JOSHUA': '24', 'JUDGES': '21', 'RUTH': '4', 'I SAMUEL': '31', 'II SAMUEL': '24', 'I KINGS': '22', 'II KINGS': '25', 'I CHRONICLES': '29', 'II CHRONICLES': '36', 'EZRA': '10', 'NEHEMIAH': '13', 'ESTHER': '10', 'JOB': '42', 'PSALMS': '150', 'PROVERBS': '31', 'ECCLESIASTES': '12', 'SONG OF SOLOMON': '8', 'ISAIAH': '66', 'JEREMIAH': '52', 'LAMENTATIONS': '5', 'EZEKIEL': '48', 'DANIEL': '12', 'HOSEA': '14', 'JOEL': '3', 'AMOS': '9', 'OBADIAH': '1', 'JONAH': '4', 'MICAH': '7', 'NAHUM': '3', 'HABAKKUK': '3', 'ZEPHANIA': '3', 'HAGGAI': '2', 'ZECHARIAH': '14', 'Malachi': '4'}

books=['GENESIS', 'EXODUS', 'LEVITICUS', 'NUMBERS', 'DEUTERONOMY', 'JOSHUA', 'JUDGES', 'RUTH', 'I SAMUEL', 'II SAMUEL', 'I KINGS', 'II KINGS', 'I CHRONICLES', 'II CHRONICLES', 'EZRA', 'NEHEMIAH', 'ESTHER', 'JOB', 'PSALMS', 'PROVERBS', 'ECCLESIASTES', 'SONG OF SOLOMON', 'ISAIAH', 'JEREMIAH', 'LAMENTATIONS', 'EZEKIEL', 'DANIEL', 'HOSEA', 'JOEL', 'AMOS', 'OBADIAH', 'JONAH', 'MICAH', 'NAHUM', 'HABAKKUK', 'ZEPHANIA', 'HAGGAI', 'ZECHARIAH', 'Malachi']

print(books.index("II SAMUEL"))

ndic={0:"\u2070",

		1:"\u00b9",		2:"\u00b2",

			3:"\u00b3",

				4:"\u2074" ,

					5:"\u2075",

						6:"\u2076",

							7:"\u2077",

								8:"\u2078",

									9:"\u2079"

										}

										

def indexOf(mainString, subString, sv):

    try:

        return mainString[sv:].index(subString) + sv

    except:

        return -1

        

#   I think return mainString.find(subString, sv) does exactly what you want with no try/except ducky_tube (and always be googling things, I wasn't sure either until I looked at https://www.w3schools.com/python/ref_string_index.asp)
