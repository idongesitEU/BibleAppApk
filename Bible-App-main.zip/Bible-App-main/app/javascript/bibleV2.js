//disable default back key action 

app.EnableBackKey( false );

cfg.Light //set theme to light

llay=app.CreateLayout( "Linear", "VCenter,FillXY" );

llay.SetBackColor( "White" );

app.AddLayout( llay );

ltx=app.AddText( llay,"HOLY BIBLE",NaN,NaN,"Bold"); ltx.SetTextSize( 70 );ltx.SetTextColor( "Blue" )

//cheek number of times app open

var file = "deyteiufe";

 var first = app.LoadBoolean( "first", true, file );

 

//create varriable to listen to current lay out

var layStatus=""; var ocs="";var newBack;

///create empty array for app objects

lays=[];

txts=[];

btns=[];//end of app objects

//create app colors

b="Blue";

w="White";

lb="#FF464646";//light black

lw="#FFC6C6C6";//light white

//ceate layout status

h="Hide";

s="Show";

//chapter object 

bChapO=//old testament chapters

{

  "Genesis": "50",

  "Exodus": "40",

  "Leviticus": "27",

  "Numbers": "36",

  "Deuteronomy": "34",

  "Joshua": "24",

  "Judges": "21",

  "Ruth": "4",

  "I. Samuel": "31",

  "II. Samuel": "24",

  "I. Kings": "22",

  "II. Kings": "25",

  "I. Chronicles": "29",

  "II. Chronicles": "36",

  "Ezra": "10",

  "Nehemiah": "13",

  "Esther": "10",

  "Job": "42",

  "Psalms": "150",

  "Proverbs": "31",

  "Ecclesiastes": "12",

  "Song of Songs": "8",

  "Isaiah": "66",

  "Jeremiah": "52",

  "Lamentations": "5",

  "Ezekiel": "48",

  "Daniel": "12",

  "Hosea": "14",

  "Joel": "3",

  "Amos": "9",

  "Obadiah": "1",

  "Jonah": "4",

  "Micah": "7",

  "Nahum": "3",

  "Habakkuk": "3",

  "Zephaniah": "3",

  "Haggai": "2",

  "Zechariah": "14",

  "Malachi": "4"

}

//create app layouts

//first layout that shows when a user opens the app for the first time

firstLay=app.CreateLayout( "Absolute", "Vcenter,FillXY" );

app.AddLayout( firstLay );

homeLay=app.CreateLayout( "Absolute", "Vertical,FillXY" )//create home layout

app.AddLayout( homeLay);//home layout

ontLay=app.CreateLayout( "Absolute", "Vertical,FillXY" );//old and new testament layout

ontLay.SetBackColor( w)

app.AddLayout( ontLay );

oldTLay=app.CreateLayout( "Absolute", "Vertical,FillXY" );//old tastement layout

newTLay=app.CreateLayout( "Absolute", "Vertical,FillXY" );//new tastement lay out

bLay=app.CreateLayout( "Absolute", "VerticalFillXY" );

slideLay=app.CreateLayout( "Card", "Linear,FillXY" )//slider layout

slideLay.SetCornerRadius( 10 )

slideLay.SetBackColor( w )

slideLay.SetSize(0.7,1  )

//horizonatal line below slide lay

hl=app.CreateImage( null,1,0.01 );

hl.SetSize(1,0.01  )

hl.SetColor( b )

bLay.AddChild( hl );

hl.DrawLine( );

app.AddLayout( oldTLay );

app.AddLayout( newTLay );

app.AddLayout(bLay);

//push all the layouts to the lays array

lays.push(firstLay);

lays.push(homeLay);

lays.push(ontLay);

lays.push(oldTLay);

lays.push(newTLay);

lays.push(bLay);

lays.push();

//hide all layouts

for(lay of lays){

lay.SetVisibility(h)

}

//create left drawer

app.AddDrawer( slideLay,"Left",0.83)

{//new and old tastement lay out design 

//create app buttons

//create layout for menu button 

slay=app.CreateLayout( "Absolute", "Horizontal,TouchSpy" )

slay.SetTouchable( true )

slay.SetOnTouch( slay_OnTouch )

ontLay.AddChild( slay )

slay.SetPosition( 0,0 )

slay.SetSize( 1,0.07 )

slay.SetBackColor( w )

//horizonatal line position

hl.SetPosition( 0,0.071 )

slay.SetVisibility( s )

ontLay.ChildToFront( slay )

slider=app.CreateButton( "MENU")

slider.SetBackColor( b )

slider.SetTextColor( w)

slay.AddChild( slider )

slider.SetTextSize( 15)

slider.SetPosition( 0,0.015)

slider.SetOnTouch( slider_OnTouch )

//end of slider

//create list for slider

ea=[];

eapus="";

for(let i=0;i<1;i++){

ea.push(eapus)

if(i===8){

ea.push("Exit")

}

}

exitList=app.CreateList(["Exit" ]);

slideLay.AddChild( exitList )

exitList.SetTextColor( "Red" )

exitList.SetOnTouch( slideLst_OnTouch )

exitList.SetTextMargins( 0.01,0.8 )

slideLst=app.CreateList(["Home","Donate","Random Verse","Quote of the day,Old Testament,New Testament",...ea] )

slideLst.SetTextColor( b )

slideLst.SetMargins( 0.0,0.03)

slideLay.AddChild( slideLst )

slideLst.SetOnTouch( slideLst_OnTouch )

//create app list

ontLst=app.CreateList( ["Old Testament","New Testament"],1 )//old and new tastement layouts

ontLst.SetPosition( 0,0.08 )

ontTxt1=app.AddText( slay,"HOLY BIBLE",1,0.07,"AutoSize,Bold" )

ontTxt1.SetPosition( 0.058,0 )

ontLst.SetTextSize( 30,"ps" )

ontTxt1.SetTextColor( b)

ontLst.SetTextColor(b)

ontLst.SetDivider( 0.00285,b)

ontLay.AddChild( ontLst )

ontLst.SetOnTouch( ontLst_OnTouch )

//add images

hoLine=app.AddImage( ontLay,null,1,0.004 )

hoLine.SetColor( w )

hoLine.SetPosition( 0,0.1992125)

hoLine.DrawLine(  )

}//end of ont lay

//add slay to all app layouts

{//design home layout

homeLay.SetBackColor( w )

//header layout for home page 

let htLay=app.CreateLayout( "Absolute", "Horizontal" )

htLay.SetSize( 1,0.075 )

htLay.SetBackColor( w )

homeLay.AddChild( htLay )

//create menu lay button

let btn=app.CreateButton( "MENU" )

btn.SetTextSize( 15 )

btn.SetBackColor( b )

btn.SetTextColor( w )

htLay.AddChild( btn )

btn.SetPosition( 0,0.012 )

btn.SetOnTouch( slay_OnTouch )

let hthTxt=app.AddText( htLay,"HOLY BIBLE",0.587,0.1 ,"AutoSize,NoWrap,Bold")

hthTxt.SetTextSize( 40 )

hthTxt.SetTextColor( b )

hthTxt.SetPosition( 0.25,0 )

//create card layout for quote of the day

qclay=app.CreateLayout( "Card", "Vertical" )

homeLay.AddChild( qclay )

qclay.SetPosition( 0.025,0.152 )

qclay.SetCornerRadius(8)

qtxt=app.AddText( qclay,"BIBLE QUOTE  OF THE DAY", 0.95,0.1,"AutoSize,Bold")

qtxt.SetTextColor( b )

qclay.SetSize( 0.95)

qclay.SetBackColor(w)

bpc=0.65//sets the position of each button 

//create an array of buttons

hBtns=["DONATE","RANDOM VERSES","READ BIBLE"]

hBtn=[]

for (bt of hBtns){

btc=app.CreateButton( bt,0.7,NaN,"Bold" )

btc.SetBackColor( w )

btc.SetTextColor( b )

btc.SetTextSize( 20 )

hBtn.push(btc)

}

for(let i=0;i<hBtn.length;i++){

hBtn[i].SetPosition(0.15,bpc)

homeLay.AddChild(hBtn[i] )

bpc+=0.1

}

hBtn[2].SetOnTouch(rb_OnTouch)//when read bible button is clicked

}//en of home layout design

{//design old tastement layout

oldTLay.SetBackColor( w)

let htLay=app.CreateLayout( "Absolute", "Horizontal" )

htLay.SetSize( 1,0.071 )

htLay.SetBackColor( w )

oldTLay.AddChild( htLay )

//create menu lay button

let btn=app.CreateButton( "MENU" )

btn.SetTextSize( 15 )

btn.SetBackColor( b )

btn.SetTextColor( w )

htLay.AddChild( btn )

btn.SetPosition( 0,0.012 )

btn.SetOnTouch( slay_OnTouch )

let hthTxt=app.AddText( htLay,"HOLY BIBLE",0.587,0.1,"AutoSize,NoWrap,Bold")

hthTxt.SetTextSize( 40 )

hthTxt.SetTextColor( b )

hthTxt.SetBackAlpha( 0 )

htLay.SetBackAlpha( 0 )

hthTxt.SetPosition( 0.25,0 )

let oldLst=app.CreateList( ["Genesis","Exodus","Leviticus","Numbers","Deuteronomy","Joshua","Judges","Ruth","I. Samuel","II. Samuel","I. Kings","II. Kings","I. Chronicles","II. Chronicles","Ezra","Nehemiah","Esther","Job","Psalms","Proverbs","Ecclesiastes","Song of Songs","Isaiah","Jeremiah","Lamentations","Ezekiel","Daniel","Hosea","Joel","Amos","Obadiah","Jonah","Micah","Nahum","Habakkuk","Zephaniah","Haggai","Zechariah","Malachi"],1,0.985,"ShowScroll" );               

oldLst.SetTextColor( b)

oldLst.SetDivider( 0.0025,b)

oldLst.SetPosition( 0,0.065)

oldTLay.AddChild( oldLst )

oldLst.SetMargins( 0.0,0,0,0.1)

let img=app.CreateImage( null, 1,0.1 )

img.SetColor( b )

img.DrawLine(  )

oldTLay.AddChild( img )

img.SetPosition( 0.9 )

oldLst.SetOnTouch( oldLst_OnTouch )//when the user clicks old lst

{//create bible view layout 

bviewbck=app.CreateLayout( "Absolute", "Vertical" )

bviewbck.SetBackColor( w)

bviewbck.SetSize( 1, 0.929);

oldTLay.AddChild(  bviewbck)

bviewbck.SetPosition( 0,0.070)

bviewbck.SetVisibility( h )

//diaplay clicked item

bvtxt=app.AddText( bviewbck,"",1,0.032997698554,"" )

bvtxt.SetBackColor( "#c2baba")

bvtxt.SetTextColor( b)

bvtxt.SetTextSize( 20 )

bvtxt.SetBackAlpha( 0 )

//draw horizontal line

lne=app.CreateImage( null, 1,0.003 )

lne.SetColor( b)

bviewbck.AddChild( lne )

lne.DrawLine(  )

lne.SetPosition(0,0.0000969013)

ocLst=app.AddList( bviewbck,[],1,bviewbck.GetHeight(  )-0.02,"ShowScroll")

ocLst.SetTextColor(b)

ocLst.SetDivider(0.0015,b)

ocLst.SetPosition( 0,0.025)

ocLst.SetOnTouch( ocLst_OnTouch )

readMode=app.CreateLayout( "Absolute", "Vertical" );//used to display bible text

oldTLay.AddChild( readMode );

readMode.SetSize( 1,0.929 );

readMode.SetVisibility( h )

readMode.SetPosition( 0,0.1 )

scrl=app.CreateScroller(1,0.9,"Vertical" );

readMode.AddChild( scrl )

txtBk=app.CreateLayout( "Linear", "Vertical" )

txtBk.SetSize(1,0.9  )

txtBk.SetBackColor( w)

scrl.AddChild( txtBk )

rmTxt=app.CreateText( "",0.94,NaN,"MultiLine,ShowScroll,Left" );

rmTxt.SetTextColor( b);

rmTxt.SetTextSize( 20 )

txtBk.AddChild( rmTxt )

scrl.SetBackColor( w )

}// end designing bible view layout

}//end of old testament layout 

{//design new tastement layout

newTLay.SetBackColor( w )

let htLay=app.CreateLayout( "Absolute", "Horizontal" )

htLay.SetSize( 1,0.071 )

htLay.SetBackColor( w )

newTLay.AddChild( htLay )

//create menu lay button

let btn=app.CreateButton( "MENU" )

btn.SetTextSize( 15 )

btn.SetBackColor( b )

btn.SetTextColor( w )

htLay.AddChild( btn )

btn.SetPosition( 0,0.012 )

btn.SetOnTouch( slay_OnTouch )

let hthTxt=app.AddText( htLay,"HOLY BIBLE",0.587,0.1 ,"AutoSize,NoWrap,Bold")

hthTxt.SetTextSize( 40 )

hthTxt.SetTextColor( b )

hthTxt.SetPosition( 0.25,0 )

let newLst=app.CreateList( ["Matthew","Mark","Luke","John","Acts","Romans"," Corinthians"," Corinthians","Galatians","Ephesians","Philippians","Colossians"," Thessalonians"," Thessalonians"," Timothy"," Timothy","Titus","Philemon","Hebrews","James"," Peter"," Peter"," John"," John"," John","Jude","Revelation"],1,0.9857)              

newLst.SetTextColor( b)

newLst.SetDivider( 0.0025,b )

newLst.SetPosition( 0,0.065)

newTLay.AddChild( newLst )

newLst.SetMargins( 0.0,0,0,0.1)

let img=app.CreateImage( null, 1,0.1 )

img.SetColor( b )

img.DrawLine(  )

oldTLay.AddChild( img )

img.SetPosition( 0.9 )

}//end of new testament design

{//design first layout

firstLay.SetBackColor( b )

//add card layout

let fclay=app.CreateLayout( "Card","Vertical,AutoSize" )

firstLay.AddChild( fclay )

fclay.SetBackColor( w )

fclay.SetElevation( 20)

fclay.SetCornerRadius( 10 )

fclay.SetSize( 0.93,0.5)

let ftxt=app.AddText( fclay,"With the advent of the internet, temptation for sin has never been greater; however, the internet also brings a great opportunity for witnessing and spreading God’s word.  It is my hope that by making this App  version of the Holy Bible available in the public domain, more people will discover God’s word that may not have otherwise.",0.92,0.75351,"MultiLine,Bold" )

ftxt.SetTextSize( 26 )

ftxt.SetTextColor( b)

fclay.SetPosition(0.035,0.179  )

//create button

let fbtn=app.CreateButton( "Read Bible》》》" ,NaN,NaN,"Bold")

firstLay.AddChild( fbtn )

fbtn.SetTextSize( 30 )

fbtn.SetTextColor( b )

let fbw=fbtn.GetWidth(  )

let fp=(1-fbw)/2

fbtn.SetPosition( fp,0.85 )

fbtn.SetOnTouch( fbtn_OnTouch )

}//end design of forsf layout

///button functions defined here

function ontLst_OnTouch(item){

ocLst.RemoveAll()

if(item=="Old Testament"){//when old testament is tourched

layStatus="oldt";

closeLays();

oldTLay.SetVisibility( s )

oldTLay.Animate( "SlideFromLeft" )

}else if(item=="New Testament"){

layStatus="newt";

closeLays();

newTLay.SetVisibility( s )

newTLay.Animate( "SlideFromLeft")

}else if(item=="Exit"){

app.Exit(  )

}

}

function rb_OnTouch(){//read bible button

layStatus="ont"

closeLays()//hide all layouts

ontLay.SetVisibility( s )//show ontLayout

}

function slider_OnTouch(){

app.OpenDrawer( "left" )

}

function slay_OnTouch(){

app.OpenDrawer( "left" )

}

function di_OnTouch(res){

if(res=="Yes"){

app.Exit(  )

}else if(res=="No" && newBack=="clicked"){

newBack="unclicked"

}

}

function slideLst_OnTouch(name){//when an item on the slide bar is tourched

if(layStatus!="obvm"){

bvtxt.SetText( ocs )

}

readMode.SetVisibility( h )

ocLst.RemoveAll()

bviewbck.SetVisibility( h )

if(name=="Old Testament"){

ocLst.RemoveAll()

app.CloseDrawer( "left" )

bviewbck.SetVisibility( h )

ocLst.RemoveAll()

ontLst_OnTouch(name)

}else if(name=="Home"){

ocLst.RemoveAll()

ocLst.RemoveAll()

bviewbck.SetVisibility( h )

if(layStatus != "home"){

closeLays();

fbtn_OnTouch()

app.CloseDrawer( "left" )

}

}else if(name=="New Testament"){

bviewbck.SetVisibility( h )

ocLst.RemoveAll()

closeLays();

ontLst_OnTouch(name);

app.CloseDrawer( "left" )

}else if(name=="Exit"){

newBack="clicked";

OnBack()

}

}

function closeLays(){//closes all layouts

ocLst.RemoveAll()

for (lay of lays){

lay.SetVisibility( h )

}

}

//on start function 

function OnStart(){

if(first){

      firstLay.SetVisibility( s )

      firstLay.Animate( "Fall" )

    app.SaveBoolean( "first", false, file );

    }else{

    fbtn_OnTouch()

   

}

}

//end on start

//back key function

function OnBack(){

if(ocLst.GetVisibility()!==true){

bvtxt.SetText( ocs)

}

if(layStatus=="home" ||  newBack=="clicked"){

di=app.CreateYesNoDialog( "Are you sure to exit the app?" )

di.SetOnTouch( di_OnTouch )

di.Show()

}else if(layStatus=="ont"){

closeLays()

layStatus="home"

homeLay.SetVisibility( s )

homeLay.Animate( "SlideFromBottom" )

}else if(layStatus=="oldt"){

closeLays();

layStatus="ont"

ontLay.SetVisibility( s )

}else if (layStatus=="newt"){

layStatus="ont";

closeLays();

ontLay.SetVisibility( s )

}else if(layStatus=="blay"){

bviewbck.Animate( "SlideToBottom")

bviewbck.SetVisibility( h )

ocLst.RemoveAll()

layStatus="ont"

}else if(layStatus=="obvm"){//when a chapter is being read

layStatus="blay"

readMode.Animate( "SlideToBottom" )

readMode.SetVisibility( h )

}

}

function oldLst_OnTouch(name){///clalled when the user clicks on a book in old tastement

layStatus="blay"//set lay status

ocs=name

bviewbck.SetVisibility( s )

bviewbck.Animate( "SlideFromBottom" )

bvtxt.SetText( name+ "")

for(let i=1;i<=bChapO[name.toString()];i+=1){

ocLst.AddItem( `Chapter ${i}`)

}

}

function ocLst_OnTouch (name){//when a chapter is clicked

layStatus="obvm"//set laystatus

bvtxt.SetText( ocs+ ": "+name)

scrl.ScrollTo( 0,0 )

readMode.SetVisibility( s );

readMode.Animate( "SlideFromBottom" )

spc=" ".repeat(1)

rmTxt.SetText(spc+ "always true, but I don’t want to get too far ahead right now. Remember, we’re still in metaphor territory.) Still, the metaphor is useful enough that it’s worth pursuing. The Game of Big Bux I’ve invented my own board game to continue down the road with this particular metaphor. In the sense that art mirrors life, the Game of Big Bux mirrors life in Silicon Valley, where money seems to be spontaneously created (generally in somebody else’s pocket) and the three big Money Black Holes are fast cars, California real estate, and messy divorces. There is luck, there is work, and assets often change hands very quickly. Aportion of the Big BuxgameboardisshowninFigure1-1.The lineof rectanglesontheleftsideofthepagecontinuesallthewayaroundtheboard.Inthe middleoftheboardarecubbyholestostoreyourplaymoneyandgamepieces; stacks of cards to be read occasionally; and short detours with names such as Messy Divorce and Start a Business, which are brief sequences of the same sort of action squares as those forming the path around the edge of the board. These are ‘‘side paths’’ that players take when instructed, either by a square on the board or a card pulled during the game. If you land on a square that tells you to Start a Business, you go through that detour. If you jump over the square, you don’t take the detour, and just keep on trucking around the board. Unlike many board games, you don’t throw dice to determine how many steps around the board you take. Big Bux requires that you move one step forward on each turn, unless the square you land on instructs you to move forward or backward or go somewhere else, such as through a detour. This makes for a considerably less random game. In fact, Big Bux is a pretty linear experience, meaning that for the most part you go around the board until you’re told that the game is over. At that point, you may be bankrupt; if not, you can total up your assets to see how well you’ve done. There is some math involved. You start out with a condo, a cheap car, and $250,000 in cash. You can buy CDs at a given interest rate, payable each time you make it once around the board. You can invest in stocks and other securities whose value is determined by a changeable index in economic indicators, which fluctuates based on cards chosen from the stack called the Fickle Finger of Fate. You can sell cars on a secondary market, buy and sell houses,condos,andland;andwheelanddealwiththeotherplayers.Eachtime you make it once around the board, you have to recalculate your net worth. All of this involves some addition, subtraction, multiplication, and division, but there’s no math more complex than compound interest. Most of Big Bux involves nothing more than taking a step and following the instructions at each step. Is this starting to sound familiar?                                         ....." )

rmTxt.SetBackColor( "#f2f6fc" )

}

//start app

function fbtn_OnTouch(){

homeLay.SetVisibility(s )

homeLay.Animate("SlideFromBottom" )

layStatus="home"

}

function OnPause(){

}

llay.DestroyChild( ltx )
