app.SetDebugEnabled(false); //disable debugging
cfg.Light
const jchapO = app.ReadFile("Misc/chapterMap.json")
chapterMap = JSON.parse(jchapO)

const jchapN = app.ReadFile("Misc/chapterMapN.json")
chapterMapN = JSON.parse(jchapN);



const booksO = ['GENESIS', 'EXODUS', 'LEVITICUS', 'NUMBERS',
	'DEUTERONOMY', 'JOSHUA', 'JUDGES', 'RUTH', 'I SAMUEL',
	'II SAMUEL', 'I KINGS', 'II KINGS', 'I CHRONICLES',
	'II CHRONICLES', 'EZRA', 'NEHEMIAH', 'ESTHER', 'JOB', 'PSALMS',
	'PROVERBS', 'ECCLESIASTES', 'SONG OF SOLOMON', 'ISAIAH',
	'JEREMIAH', 'LAMENTATIONS', 'EZEKIEL', 'DANIEL', 'HOSEA',
	'JOEL', 'AMOS', 'OBADIAH', 'JONAH', 'MICAH', 'NAHUM',
	'HABAKKUK', 'ZEPHANIA', 'HAGGAI', 'ZECHARIAH', 'Malachi'
]
const booksN = ['MATTHEW', 'MARK', 'LUKE', 'JOHN', 'ACTS', 'ROMANS',
	'I CORINTHIANS', 'II CORINTHIANS', 'GALATIANS', 'EPHESIANS',
	'PHILIPPIANS', 'COLOSSIANS', 'I THESSALONIANS',
	'II THESSALONIANS', 'I TIMOTHY', 'II TIMOTHY', 'TITUS',
	'PHILEMON', 'HEBREWS', 'JAMES', 'I PETER', 'II PETER', 'I JOHN',
	'II JOHN', 'III JOHN', 'JUDE', 'REVELATION'
];

const bibleOJ = app.ReadFile("Misc/oldT.json"); //old testament file
const bibleO = JSON.parse(bibleOJ);


const bibleNJ = app.ReadFile("Misc/newT.json"); //new testament file
const bibleN = JSON.parse(bibleNJ);
//database

app.EnableBackKey(false); //disable  back key


app.SetOrientation("Potrait"); //force potrait

var dbfile = "datafile"; //database file
var ldb; //liquid database
db = app.LoadText("user", "{\"times\":1,\"mode\":\"dark\"}", dbfile);
ldb = JSON.parse(db);

const writeDB = (/*column,value*/) => {
	//write database
	//ldb[column]=value;
	const privateData = JSON.stringify(ldb);
	app.SaveText("user", privateData, dbfile);

}


var openLays = []; //array for open layouts
var state = [];
var b = "#000000"
var lb = "#121212"
var btnb = "#303133";
var w = "white";

var hLogAr = []; //hlog arrray
var hLog;

//*********************layer1*****************************"********//


{
	//drawer container
	dlay = app.CreateLayout("Linear", "Vertical,FillXY"); //create drawer.layout
	dlay.SetBackColor("black")
	drawer = app.AddDrawer(dlay, "left", 0.8, 1); //create drawer.layout

	//drawer container
	const theme = app.AddText(dlay, "THEME")
	theme.SetTextSize(20)
	theme.SetMargins(NaN, 0.0)

	hdlay = app.CreateLayout("Linear", "Horizontal"); //light and dark theme buttons
	dlay.AddChild(hdlay);

	const light = app.CreateButton("LIGHT", -1, -1, "") //Light theme  Button
	light.SetTextSize(22)
	hdlay.AddChild(light)
	light.SetOnTouch(lightMode)

	//+
	function lightMode() {

		app.CloseDrawer("left")
		//light mode function
		ldb["mode"] = "light";
		writeDB(); //update theme database
		dtheme();
		setTheme();



	}

	const dark = app.CreateButton("DARK", -1, -1, "") //Light theme  Button
	dark.SetTextSize(22);
	hdlay.AddChild(dark);
	dark.SetOnTouch(darkMode);

	//+
	function darkMode() {

		app.CloseDrawer("left");
		//dark mode function
		ldb["mode"] = "dark";
		writeDB(); //update theme database
		dtheme();
		setTheme();


	}


	//drawer list

	const drawlistcard = app.CreateLayout("card")
	drawlistcard.SetCornerRadius(10);
	drawlistcard.SetElevation(3)
	drawlistcard.SetMargins(NaN, 0.1);
	dlay.AddChild(drawlistcard);


	const vc = app.CreateLayout("Linear", "VCenter")
	drawlistcard.AddChild(vc);

	var drawListAction;

	drawerListItems =
	"DONATE / REMOVE ADs,HOW TO USE,PRIVACY POLICY,CONTACT US,SHARE APP,HISTORY,FAVOURITE,OLD TESTAMENT,NEW TESTAMENT,HOME"

	dlist = app.AddList(vc, drawerListItems, 0.75, NaN)
	dlist.SetOnTouch(dlistAction)

	//++
	function dlistAction(name) {

		drawListAction(name);

	}

	//++
	function dtheme() {
		//set drawer theme
		ldb.mode == "light" ? dlay.SetBackColor("white"): dlay.SetBackColor(
			"#000000")

		if (ldb.mode == "light") {
			dlist.SetBackColor("white")
			dlist.SetTextColor("black")


			dark.SetBackColor(w)
			light.SetBackColor(w)
			light.SetTextColor("black")
			dark.SetTextColor("black")



			app.ShowPopup("light mode");

		} else if (ldb.mode == "dark") {

			dlist.SetBackColor(lb)
			dlist.SetTextColor("white")
			light.SetBackColor("#303133")
			dark.SetBackColor("#303133")
			light.SetTextColor("white")
			dark.SetTextColor("white")


			app.ShowPopup("dark  mode");

		}

	}

	const exit = app.CreateButton("EXIT", 0.7)
	exit.SetTextColor("white")
	exit.SetBackColor("RED")
	exit.SetOnTouch(exit_OnTouch)
	exit.SetMargins(0.01, 0.21, 0.01, 0.01)
	dlay.AddChild(exit)

	function exit_OnTouch() {
		//exit function
		app.CloseDrawer("left")
		alert(null, "Are you sure to exit the app?", ["Yes", "No"],
			proposeExit)

	}

}



//*****************************
function OnStart() {
	//onstart function

	const t = ldb.times + 1;
	ldb["times"] = t;
	writeDB()
	//app.ShowPopup( t )

	main();
	openLays[0].setMode();
	dtheme();
	setTheme();

}


//*******************************
function OnBack() {

	//back key function

	if (app.GetDrawerState("left") == "Open") {
		app.CloseDrawer("left")
		return true;

	} else if (openLays.length == 1) {
		alert(null, "Are you sure to exit the app?", ["Yes", "No"],
			proposeExit)
		return true;

	} else {

		openLays[openLays.length - 1].destroy();
		openLays.pop();
		state.pop()


		return true;
	}


}


//***************************
const OnPause = () => {
	//when app is paused


}


//***************************
function main() {


	//++

	drawListAction = (name) => {
		//called when the drawer list is touche

		//app.CloseDrawer( "left" )

		if (state[state.length - 1] != name) {

			if (name == "HOME") {
				app.CloseDrawer("left")
				for (let i = 1; i < openLays.length; i++) {
					openLays[i].destroy();
				}

				state.splice(1);
				openLays.splice(1)


				return true;

			}

			if (name == "OLD TESTAMENT") {
				openO();

			} else if (name == "NEW TESTAMENT") {
				openN();
			}
		} else {}

		app.CloseDrawer("left")


	}

	//______

	const openHome = () => {
		//mint home layout
		const mode = {};


		const homeLay = app.CreateLayout("Linear",
			"Vertical,FillXY");
		app.AddLayout(homeLay);


		const title = app.CreateLayout("Linear",
			"Horizontal,FillX") //title bar layout
		title.SetSize(1, -1);
		homeLay.AddChild(title);

		var menu = app.CreateButton("  MENU  ", -1, -1, "") //Menu Button

		menu.SetTextSize(22)
		title.AddChild(menu)
		menu.SetMargins(-0.150, 0.01, 0.01, 0.01)
		menu.SetOnTouch(openDrawer)

		const titleText = app.AddText(title, "HOLY BIBLE", -1, -1,
			"bold");
		titleText.SetTextSize(40)


		const card1 = app.CreateLayout("Card"); //card for daily quotes
		card1.SetElevation(20);
		card1.SetCornerRadius(10);
		card1.SetSize(0.98, 0.4);
		card1.SetMargins(NaN, 0.02);
		homeLay.AddChild(card1);


		const card2 = app.CreateLayout("card");
		card2.SetElevation(20);
		card2.SetCornerRadius(10);
		card2.SetSize(NaN, NaN);
		card2.SetMargins(NaN, 0.02);
		homeLay.AddChild(card2);

		const card2h = app.CreateLayout("Linear", "Horizontal") //holds history,donate and favourite buttons
		card2.AddChild(card2h);

		const donatebtn = app.CreateButton("DONATE", -1, -1, "")
		card2h.AddChild(donatebtn)


		const favouritebtn = app.CreateButton("FAVOURITES", -1, -
			1, "")
		card2h.AddChild(favouritebtn)
		//	btns.favourite.SetOnTouch(openFav);


		const historybtn = app.CreateButton("HISTORY", -1, -1, "")
		card2h.AddChild(historybtn)
		//btns.history.SetOnTouch(openHistory)







		//+
		const setMode = () => {
			const type = ldb.mode

			if (type == "light") {
				menu.SetStyle(w, w, 3, w, 3, 10)
				menu.SetTextColor("black")

				homeLay.SetBackColor("white")
				card1.SetBackColor("white");
				card2.SetBackColor("white")

				titleText.SetTextColor("black");
				title.SetBackColor("#f0f2f5")


				favouritebtn.SetTextColor(b);
				historybtn.SetTextColor(b)
				donatebtn.SetTextColor(b)

				favouritebtn.SetBackColor(w);
				historybtn.SetBackColor(w)
				donatebtn.SetBackColor(w)




			} else if (type == "dark") {
				menu.SetStyle(btnb, btnb, 3, btnb, 3, 10)

				homeLay.SetBackColor(b)
				menu.SetBackColor(btnb)
				menu.SetTextColor("white")
				card1.SetBackColor(lb)
				card2.SetBackColor(lb)
				titleText.SetTextColor("white");
				title.SetBackColor(lb)

				favouritebtn.SetTextColor(w);
				historybtn.SetTextColor(w)
				donatebtn.SetTextColor(w)

				favouritebtn.SetBackColor(btnb)
				historybtn.SetBackColor(btnb)
				donatebtn.SetBackColor(btnb)


			}

		}

		//+
		const destroy = () => {
			//destroy the layout
			app.DestroyLayout(homeLay)
		}

		mode["destroy"] = destroy;

		mode["setMode"] = setMode;

		openLays.push(mode);
		state.push("HOME");

	}

	openHome();



	//________
	function openO() {
		//open old testament

		mode = {} //return object
		state.push("OLD TESTAMENT");

		const homeLay = app.CreateLayout("Linear",
			"Vertical,FillXY");



		const title = app.CreateLayout("Linear",
			"Horizontal,FillX") //title bar layout
		title.SetSize(1, -1);
		homeLay.AddChild(title);

		var menu = app.CreateButton("  MENU  ", -1, -1, "") //Menu Button

		menu.SetTextSize(22)
		title.AddChild(menu)
		menu.SetMargins(-0.150, 0.01, 0.01, 0.01)
		menu.SetOnTouch(openDrawer)

		const titleText = app.AddText(title, "HOLY BIBLE", -1, -1,
			"bold");
		titleText.SetTextSize(40)

		app.AddLayout(homeLay);

		const scrl = app.AddScroller(homeLay);

		const scrlPad = app.CreateLayout("Linear", "Vertical,FillXY");
		scrl.AddChild(scrlPad);

		/*Code goes here*/

		const list = app.AddList(scrlPad, booksO.join(), 0.97, NaN, "Expand")
		list.SetTextSize(22)
		list.SetMargins(0.01, 0.01, 0.01, 0.1)
		list.SetOnTouch(chapter);




		//++
		const setMode = () => {
			//set mode foe old testament

			if (ldb.mode == "light") {
				menu.SetStyle(w, w, 3, w, 3, 10)
				menu.SetTextColor("black")
				homeLay.SetBackColor("white")
				titleText.SetTextColor("black");
				title.SetBackColor("#f0f2f5")

			} else if (ldb.mode == "dark") {

				menu.SetStyle(btnb, btnb, 3, btnb, 3, 10);
				homeLay.SetBackColor(b);
				menu.SetBackColor(btnb);
				menu.SetTextColor("white");
				titleText.SetTextColor("white");
				title.SetBackColor(lb)


			}

		}

		setMode();
		mode["setMode"] = setMode;

		//++

		const destroy = () => {
			app.DestroyLayout(homeLay)

		}
		mode["destroy"] = destroy;

		openLays.push(mode);



		const h = list.GetHeight();
		list.SetSize(NaN, h+0.3)


	}



	//______________
	function openN() {
		//open new testament
		mode = {} //return object
		state.push("NEW TESTAMENT");

		const homeLay = app.CreateLayout("Linear",
			"Vertical,FillXY");
		app.AddLayout(homeLay);


		const title = app.CreateLayout("Linear",
			"Horizontal,FillX") //title bar layout
		title.SetSize(1, -1);
		homeLay.AddChild(title);

		var menu = app.CreateButton("  MENU  ", -1, -1, "") //Menu Button

		menu.SetTextSize(22)
		title.AddChild(menu)
		menu.SetMargins(-0.150, 0.01, 0.01, 0.01)
		menu.SetOnTouch(openDrawer)

		const titleText = app.AddText(title, "HOLY BIBLE", -1, -1,
			"bold");
		titleText.SetTextSize(40)

		const scrl = app.AddScroller(homeLay);

		const scrlPad = app.CreateLayout("Linear", "Vertical,FillXY");
		scrl.AddChild(scrlPad);

		/*Code goes here*/

		const list = app.AddList(scrlPad, booksN.join(), 0.97, NaN, "Expand")
		list.SetTextSize(22)
		list.SetOnTouch(chapter)

		list.SetMargins(0.01, 0.01, 0.01, 0.1)



		//++
		const setMode = () => {
			//set mode foe old testament

			if (ldb.mode == "light") {
				menu.SetStyle(w, w, 3, w, 3, 10)
				menu.SetTextColor("black")
				homeLay.SetBackColor("white")
				titleText.SetTextColor("black");
				title.SetBackColor("#f0f2f5")

			} else if (ldb.mode == "dark") {

				menu.SetStyle(btnb, btnb, 3, btnb, 3, 10);
				homeLay.SetBackColor(b);
				menu.SetBackColor(btnb);
				menu.SetTextColor("white");
				titleText.SetTextColor("white");
				title.SetBackColor(lb)


			}

		}

		setMode();
		mode["setMode"] = setMode;

		//++

		const destroy = () => {
			app.DestroyLayout(homeLay)

		}
		mode["destroy"] = destroy;

		openLays.push(mode);

	}


	//___________________
	function chapter(name) {
		var chap

		const privateState = state[state.length-1];
		privateState == "OLD TESTAMENT"?chap = chapterMap: chap = chapterMapN;

		mode = {}//return object
		state.push("CHAPTER");

		const homeLay = app.CreateLayout("Linear",
			"Vertical,FillXY");



		const title = app.CreateLayout("Linear",
			"Horizontal,FillX") //title bar layout
		title.SetSize(1, -1);
		homeLay.AddChild(title);

		var menu = app.CreateButton("  MENU  ", -1, -1, "") //Menu Button

		menu.SetTextSize(22)
		title.AddChild(menu)
		menu.SetMargins(-0.150, 0.01, 0.01, 0.01)
		menu.SetOnTouch(openDrawer)

		const titleText = app.AddText(title, "HOLY BIBLE", -1, -1,
			"bold");
		titleText.SetTextSize(40)


		hLog = name; //set history log
		const logText = app.AddText(homeLay, hLog, 1, NaN, "bold")
		logText.SetTextSize(18)
		logText.SetBackColor("#ededed")


		const scrl = app.AddScroller(homeLay, 1, 0.97);

		const scrlPad = app.CreateLayout("Linear", "Vertical,FillXY");
		scrl.AddChild(scrlPad);

		/*code goes here */


		chap = chap[name]
		const list = app.AddList(scrlPad, chap.join(), 0.98, NaN, "Expand");
		list.SetOnTouch(readMode)

		list.SetMargins(0.01, 0.01, 0.01, 0.2)

		//++
		const setMode = () => {
			//set mode foe old testament

			if (ldb.mode == "light") {
				menu.SetStyle(w, w, 3, w, 3, 10)
				menu.SetTextColor("black")
				homeLay.SetBackColor("white")
				titleText.SetTextColor("black");
				title.SetBackColor("#f0f2f5")

				logText.SetBackColor("#ededed")
				logText.SetTextColor("#050505")

			} else if (ldb.mode == "dark") {

				menu.SetStyle(btnb, btnb, 3, btnb, 3, 10);
				homeLay.SetBackColor(b);
				menu.SetBackColor(btnb);
				menu.SetTextColor("white");
				titleText.SetTextColor("white");
				title.SetBackColor(lb)


			}

		}

		setMode();
		app.AddLayout(homeLay)//add home layout

		mode["setMode"] = setMode;

		//++

		const destroy = () => {
			app.DestroyLayout(homeLay)

		}
		mode["destroy"] = destroy;

		openLays.push(mode);



	}



	function readMode(name) {
		mode = {}//return object
		state.push("READMODE");
		hLog = `${hLog} ${name}`;

		const homeLay = app.CreateLayout("Linear",
			"Vertical,FillXY");



		const title = app.CreateLayout("Linear",
			"Horizontal,FillX") //title bar layout
		title.SetSize(1, -1);
		homeLay.AddChild(title);

		var menu = app.CreateButton("  MENU  ", -1, -1, "") //Menu Button

		menu.SetTextSize(22)
		title.AddChild(menu)
		menu.SetMargins(-0.150, 0.01, 0.01, 0.01)
		menu.SetOnTouch(openDrawer)

		const titleText = app.AddText(title, "HOLY BIBLE", -1, -1,
			"bold");
		titleText.SetTextSize(40)

		const logText = app.AddText(homeLay, hLog, 1, NaN, "bold")
		logText.SetTextSize(18)
		logText.SetBackColor("#ededed")


		const scrl = app.AddScroller(homeLay, 1, 0.97);

		const scrlPad = app.CreateLayout("Linear", "Vertical,FillXY");
		scrl.AddChild(scrlPad);



		/*code goes here */




		//++
		const setMode = () => {
			//set mode foe old testament

			if (ldb.mode == "light") {
				menu.SetStyle(w, w, 3, w, 3, 10)
				menu.SetTextColor("black")
				homeLay.SetBackColor("white")
				titleText.SetTextColor("black");
				title.SetBackColor("#f0f2f5")

			} else if (ldb.mode == "dark") {

				menu.SetStyle(btnb, btnb, 3, btnb, 3, 10);
				homeLay.SetBackColor(b);
				menu.SetBackColor(btnb);
				menu.SetTextColor("white");
				titleText.SetTextColor("white");
				title.SetBackColor(lb)


			}

		}

		setMode();
		app.AddLayout(homeLay);
		mode["setMode"] = setMode;

		//++

		const destroy = () => {
			app.DestroyLayout(homeLay)

		}
		mode["destroy"] = destroy;

		openLays.push(mode);

	}





}

//***************************layer 2******************************//
function proposeExit(response) {
	response == "Yes" ? app.Exit(): OnBack();
}

function yn_OnTouch(response) {}


//***************
function setTheme() {
	//set theme function
	for (let i = openLays.length-1; i>-1; i--) {
		openLays[i].setMode();
	}

}



//**********
function alert(title, text, options, callback) {
	//creates alerts.
	state.push("ALERT")
	//--
	const closeFooter = () => {

		OnBack();
	}

	//--

	var response;

	const f1 = () => {
		//when footer is clicked
		response = options[0];

		try {
			callback(response);
		} catch(e) {
			app.ShowPopup(response)
		}

	}

	const f2 = () => {
		//when footer 1 is clicked
		response = options[1];

		try {
			callback(response);
		} catch(e) {
			app.ShowPopup(response)
		}

	}

	const mode = {};

	const vc = app.CreateLayout("Linear", "VCenter,FillXY")
	vc.SetBackAlpha(0)


	const card = app.CreateLayout("card");
	card.SetCornerRadius(10)
	card.SetElevation(10)
	card.SetSize(0.965, NaN)
	vc.AddChild(card);

	const canvas = app.CreateLayout("Linear", "VCenter,FillXY")
	card.AddChild(canvas)

	const head = app.AddText(canvas, "", 1, NaN); //head text
	const body = app.AddText(canvas, "", 1, NaN, "multiline"); //body text
	body.SetTextSize(22)
	//construct footer

	const hc = app.CreateLayout("Linear", "Horizontal");
	hc.SetMargins(0.01, 0.05, 0.01, 0.01)
	canvas.AddChild(hc);


	var footer;
	var footer2;
	if (options == null) {

		footer = app.AddText(hc, "BACK", 1, NaN); //footer text
		footer.SetTextSize(21);
		footer.SetOnTouchUp(closeFooter);

	} else if (options.length == 2) {

		footer = app.AddText(hc, options[0], 0.5, NaN); //footer text
		footer.SetTextSize(21);
		footer.SetOnTouchUp(f1)

		footer2 = app.AddText(hc, options[1], 0.5, NaN); //footer text
		footer2.SetTextSize(21);
		footer2.SetOnTouchUp(f2)

	}



	head.SetTextSize(18)

	card.SetVisibility("hide")
	app.AddLayout(vc);


	//set texts
	title != null ? head.SetText(title): false;
	text != null ? body.SetText(text): false;


	vc.SetOnTouchUp(closeFooter)
	card.Animate("ZoomInEnter", NaN, 100)



	const th = ldb.mode;
	if (th == "light") {
		// vc.SetBackColor( "white" )
		footer.SetBackColor("white")
		card.SetBackColor("#ffffff");
		head.SetBackColor("#fcfcfc")
		body.SetTextColor("black ")
		head.SetTextColor("#313438")
		footer.SetTextColor("#313438")
		footer2.SetBackColor("white")
		footer2.SetTextColor("#313438")


	} else if (th == "dark") {
		//vc.SetBackColor( "#434445" )
		card.SetBackColor("#575959")
		footer.SetBackColor("#575959")
		footer2.SetBackColor("#575959")
		head.SetBackColor("#575959")

		head.SetTextColor("#4f5052")
		footer.SetTextColor("#d1d1d1")
		footer2.SetTextColor("#d1d1d1")
		body.SetTextColor("white")

	}






	//++
	const setMode = () => {}

	mode["setMode"] = setMode;



	//+
	const destroy = () => {
		//destroy alert
		app.DestroyLayout(vc)
	}

	mode["destroy"] = destroy;

	openLays.push(mode);

}



//____________



//***************************open functions*†
function openDrawer() {
	app.OpenDrawer("left")
}
