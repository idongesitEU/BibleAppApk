cfg.Light
const oner = ()=>app.SetOnError(OnError);
//oner();

var dbf = "database"; //app database
var jdb; //liquid database



app.SetOrientation("Portrait")
app.SetDebugEnabled(false)
app.EnableBackKey(false)
var status; //lay status
var lastStaus; //last status
var lightdark = "modefile"; //mode file

const b = "black", w = "white", s = "show", h = "hide";


const lays = {}; //layouts
const hLays = {}; //horizontal layouts
const lists = {}; //lists
const btns = {}; //buttons
const texts = {}; //texts

var gName; //global name
var favid; //identity for addFav function
var hLog; //history logs
const openLays = ["home"];
//app.Alert( typeof(openLays) )





const chapterMap = {
	'GENESIS': '50',
	'EXODUS': '40',
	'LEVITICUS': '27',
	'NUMBERS': '36',
	'DEUTERONOMY': '34',
	'JOSHUA': '24',
	'JUDGES': '21',
	'RUTH': '4',
	'I SAMUEL': '31',
	'II SAMUEL': '24',
	'I KINGS': '22',
	'II KINGS': '25',
	'I CHRONICLES': '29',
	'II CHRONICLES': '36',
	'EZRA': '10',
	'NEHEMIAH': '13',
	'ESTHER': '10',
	'JOB': '42',
	'PSALMS': '150',
	'PROVERBS': '31',
	'ECCLESIASTES': '12',
	'SONG OF SOLOMON': '8',
	'ISAIAH': '66',
	'JEREMIAH': '52',
	'LAMENTATIONS': '5',
	'EZEKIEL': '48',
	'DANIEL': '12',
	'HOSEA': '14',
	'JOEL': '3',
	'AMOS': '9',
	'OBADIAH': '1',
	'JONAH': '4',
	'MICAH': '7',
	'NAHUM': '3',
	'HABAKKUK': '3',
	'ZEPHANIA': '3',
	'HAGGAI': '2',
	'ZECHARIAH': '14',
	'Malachi': '4'
}
const chapterMapN = bdic = {
	'MATTHEW': ' 28',
	'MARK': ' 16',
	'LUKE': ' 24',
	'JOHN': ' 21',
	'ACTS': ' 28',
	'ROMANS': ' 16',
	'I CORINTHIANS': ' 16',
	'II CORINTHIANS': ' 13',
	'GALATIANS': ' 6',
	'EPHESIANS': ' 6',
	'PHILIPPIANS': '4',
	'COLOSSIANS': ' 4',
	'I THESSALONIANS': ' 5',
	'II THESSALONIANS': ' 3',
	'I TIMOTHY': ' 6',
	'II TIMOTHY': ' 4',
	'TITUS': ' 3',
	'PHILEMON': ' 1',
	'HEBREWS': ' 13',
	'JAMES': ' 5',
	'I PETER': ' 5',
	'II PETER': ' 3',
	'I JOHN': ' 5',
	'II JOHN': ' 1',
	'III JOHN': ' 1',
	'JUDE': ' 1',
	'REVELATION': ' 22'
};


const booksO = ['GENESIS', 'EXODUS', 'LEVITICUS', 'NUMBERS', 'DEUTERONOMY', 'JOSHUA', 'JUDGES', 'RUTH', 'I SAMUEL', 'II SAMUEL', 'I KINGS', 'II KINGS', 'I CHRONICLES', 'II CHRONICLES', 'EZRA', 'NEHEMIAH', 'ESTHER', 'JOB', 'PSALMS', 'PROVERBS', 'ECCLESIASTES', 'SONG OF SOLOMON', 'ISAIAH', 'JEREMIAH', 'LAMENTATIONS', 'EZEKIEL', 'DANIEL', 'HOSEA', 'JOEL', 'AMOS', 'OBADIAH', 'JONAH', 'MICAH', 'NAHUM', 'HABAKKUK', 'ZEPHANIA', 'HAGGAI', 'ZECHARIAH', 'Malachi']
const booksN = ['MATTHEW', 'MARK', 'LUKE', 'JOHN', 'ACTS', 'ROMANS', 'I CORINTHIANS', 'II CORINTHIANS', 'GALATIANS', 'EPHESIANS', 'PHILIPPIANS', 'COLOSSIANS', 'I THESSALONIANS', 'II THESSALONIANS', 'I TIMOTHY', 'II TIMOTHY', 'TITUS', 'PHILEMON', 'HEBREWS', 'JAMES', 'I PETER', 'II PETER', 'I JOHN', 'II JOHN', 'III JOHN', 'JUDE', 'REVELATION'];

const bibleOJ = app.ReadFile("Misc/oldT.json"); //old testament file
const bibleO = JSON.parse(bibleOJ);


const bibleNJ = app.ReadFile("Misc/newT.json"); //new testament file
const bibleN = JSON.parse(bibleNJ);






//******************************LAYER 1*******************************//



{
	//mint layouts for home

	lays["home"] = app.CreateLayout("Linear", "VCenter,FillXY")//home layout
	app.AddLayout(lays.home)
	//shown when app is loading
	loadLay = app.CreateLayout("Linear", "VCenter,FillXY");
	loadLay.SetSize(1, 1)
	loadLay.SetBackColor(b)
	lays.home.AddChild(loadLay)
	loadText = app.AddText(loadLay, "HOLY BIBLE", NaN, NaN, "bold");
	loadText.SetTextColor(w)
	loadText.SetTextSize(60)



	lays["title"] = app.CreateLayout("Linear", "Horizontal,FillX")//title bar layout
	lays.title.SetSize(-1, -1)
	lays.home.AddChild(lays.title)


	lays["drawer"] = app.CreateLayout("Linear", "Vertical,FillXY"); //create drawer.layout


	lays["parent"] = app.CreateLayout("Linear", "Vertical,FillXY"); //display parent
	lays.home.AddChild(lays.parent);
	//cards
	lays["card1"] = app.CreateLayout("Card")//card for daily quotes
	lays.card1.SetElevation(20)
	lays.card1.SetCornerRadius(10)
	lays.card1.SetSize(0.95, 0.4)
	lays.card1.SetMargins(NaN, 0.02)
	lays.parent.AddChild(lays.card1)

	lays["card2"] = app.CreateLayout("Card", "Horizontal")
	/*lays["card2"].SetElevation(10);
lays["card2"].SetCornerRadius(10);*/
	tuneCard(lays["card2"])
	lays.card2.SetSize(-1, -1);
	lays.parent.AddChild(lays.card2);



}





{
	//daily reading;

	hLays["daily"] = app.CreateLayout("Linear", "Vertical,FillXY");
	lays.card1.AddChild(hLays.daily)

	texts["titleD"] = app.AddText(hLays.daily, "TODAY\'s READING", 1, NaN, "bold")
	texts.titleD.SetTextSize(19)
	texts.titleD.SetOnTouchUp(openD);

	hLays["scrld"] = app.CreateScroller(0.94, 0.39, "VCenter");
	//hLays.scrld.SetSize(0.98,0.4);
	//hLays.scrld.SetBackColor("red");
	hLays.daily.AddChild(hLays.scrld);

	hLays["dailyread"] = app.CreateLayout("Linear", "VCenter");
	hLays.scrld.AddChild(hLays.dailyread);

	texts["daily"] = app.AddText(hLays.dailyread, "", 0.93, NaN, "Multiline,Left")

	texts.daily.SetTextSize(18)


}






{
	//old tastement

	lays["oldT"] = app.CreateLayout("Linear", "Vertical,FillXY")
	lays.oldT.SetSize(1, 1)
	lays.oldT.SetVisibility("hide");
	app.AddLayout(lays.oldT)

	lays["titleO"] = app.CreateLayout("Linear", "Horizontal,FillX")//title bar layout
	lays.titleO.SetSize(-1, -1)
	lays.oldT.AddChild(lays.titleO)
	lays.titleO.SetMargins(NaN, 0)

	btns["drawerO"] = app.CreateButton("MENU", -1, -1, "")//Menu Button
	btns.drawerO.SetTextSize(22)
	lays.titleO.AddChild(btns.drawerO)
	btns.drawerO.SetOnTouch(openDrawer)
	btns["drawerO"].SetMargins(-0.15, 0.007)
	//ot=app.AddText( lays.oldT,"Baby" )


	texts["titleO"] = app.CreateText("HOLY BIBLE", -1, -1, "Bold"); //Title text
	texts.titleO.SetTextSize(40);
	lays.titleO.AddChild(texts.titleO);

	lays["absO"] = app.CreateLayout("Linear", "Vertical,FillXY");
	lays.absO.SetSize(1, 0.95)
	lays.oldT.AddChild(lays.absO)

	lays["scrlO"] = app.AddScroller(lays.absO, 1, 0.95)
	lays.absO.AddChild(lays.scrlO)

	lays["chapO"] = app.CreateLayout("Linear", "Vertical,FillXY")
	lays.scrlO.AddChild(lays.chapO)
	lays.chapO.SetSize(1, 1)

	lists["chapO"] = app.AddList(lays.chapO, "", NaN, NaN, "Expand")//old tastement books

	texts["catalystO"] = app.AddText(lays.chapO, 1, 0.2)
	//lays.chapO.SetSize(NaN,lists.chapO.GetHeight()+0.2)

	/*for (var book of booksO){
lists.chapO.AddItem(book);
}*/

	//app.ShowPopup( lists.chapO.GetLength() )

	lists.chapO.SetTextSize(22)//list for books
	lists.chapO.SetOnTouch(openO)

	for (var book of booksO) {

		lists.chapO.AddItem(book)

	}


	const temph = lists.chapO.GetHeight(); //initial height of list
	lists.chapO.SetSize(NaN, temph+0.1)


	liquid = mintT(); //mint chapter layout

	lays["chapterO"] = mintL();
	lays.chapterO.SetVisibility(h);
	app.AddLayout(lays.chapterO)


	lays["titleTO"] = liquid[0];
	lays.chapterO.AddChild(lays.titleTO)

	btns["titleTO"] = liquid[1];

	texts["titleTO"] = liquid[2];

	texts["cinfo1O"] = app.AddText(lays.chapterO, "", 1, NaN, "bold");
	texts.cinfo1O.SetTextSize(18)


	lists["chapListO"] = app.AddList(lays.chapterO, "");
	lists.chapListO.SetOnTouch(readMode)

	lists.chapListO.SetTextSize(22)


	//read mode display
	lays["readScrl"] = app.CreateScroller(1, 1)
	liquid = mintT();
	lays["readMode"] = mintL();
	lays["titleR"] = liquid[0];
	lays.readMode.AddChild(lays.titleR);
	btns["titleR"] = liquid[1];
	texts["titleR"] = liquid[2]
	lays.readMode.SetVisibility(h);
	app.AddLayout(lays.readMode)

	texts["cinfo2O"] = app.AddText(lays.readMode, "", 1, NaN, "bold");
	texts.cinfo2O.SetTextSize(18)

	lays.readMode.AddChild(lays.readScrl)

	lays["reader"] = app.CreateLayout("Linear", "Vertical")
	//lays.reader.SetSize(-1,-1)
	lays.readScrl.AddChild(lays.reader)
	texts["rText"] = app.AddText(lays.reader, "", 0.98, null, "Left,Multiline")
	texts.rText.SetMargins(0.01)
	texts.rText.SetTextSize(22)
}


{
	//new tastement
	lays["newT"] = app.CreateLayout("Linear", "Vertical,FillXY")
	lays.newT.SetVisibility("hide");
	app.AddLayout(lays.newT)


	lays["titleN"] = app.CreateLayout("Linear", "Horizontal,FillX")//title bar layout
	lays.titleN.SetSize(-1, -1)
	lays.newT.AddChild(lays.titleN)

	btns["drawerN"] = app.CreateButton("MENU", -1, -1, "")//Menu Button
	btns.drawerN.SetTextSize(22)
	lays.titleN.AddChild(btns.drawerN)
	btns.drawerN.SetOnTouch(openDrawer)
	btns["drawerN"].SetMargins(-0.15, 0.007)
	//ot=app.AddText( lays.newT,"Babyl" )



	texts["titleN"] = app.CreateText("HOLY BIBLE", -1, -1, "Bold"); //Title text
	texts.titleN.SetTextSize(40);
	lays.titleN.AddChild(texts.titleN);



	lays["absN"] = app.CreateLayout("Linear", "Vertical,FillXY");
	lays.absN.SetSize(1, 0.95)
	lays.newT.AddChild(lays.absN)

	lays["scrlN"] = app.AddScroller(lays.absN, 1, 0.95)
	lays.absN.AddChild(lays.scrlN)

	lays["chapN"] = app.CreateLayout("Linear", "Vertical,FillXY")
	lays.scrlN.AddChild(lays.chapN)
	lays.chapN.SetSize(1, 1)

	lists["chapN"] = app.AddList(lays.chapN, booksN.join(), NaN, NaN, "Expand")//new tastement books

	const temph = lists.chapN.GetHeight(); //initial height of list
	lists.chapN.SetSize(NaN, temph+0.3)

	//texts["catalystN"]=app.AddText( lays.chapN,"",1,0.1 )


	lists.chapO.SetTextSize(22)//list for books
	lists.chapO.SetOnTouch(openO)


	/*
	for (var book of booksN) {

		lists.chapN.AddItem(book)

	}
	*/


	lists.chapN.SetTextSize(22);
	lists.chapN.SetOnTouch(openN);




	liquid = mintT(); //mint chapter layout

	lays["chapterN"] = mintL();
	app.AddLayout(lays.chapterN)
	lays.chapterN.SetVisibility(h);

	lays["titleTN"] = liquid[0];
	lays.chapterN.AddChild(lays.titleTN)

	btns["titleTN"] = liquid[1];

	texts["titleTN"] = liquid[2];

	texts["cinfo1"] = app.AddText(lays.chapterN, "", 1, NaN, "bold");
	texts.cinfo1.SetTextSize(18)




	lists["chapListN"] = app.AddList(lays.chapterN, "");
	lists.chapListN.SetOnTouch(readModeN)

	lists.chapListO.SetTextSize(22)


	//read mode display
	lays["readScrlN"] = app.CreateScroller(1, 1)
	liquid = mintT();
	lays["readModeN"] = mintL();
	lays["titleRN"] = liquid[0];
	lays.readModeN.AddChild(lays.titleRN);
	btns["titleRN"] = liquid[1];
	texts["titleRN"] = liquid[2]
	lays.readModeN.SetVisibility(h);
	app.AddLayout(lays.readModeN)

	texts["cinfo2"] = app.AddText(lays.readModeN, "", 1, NaN, "bold");
	texts.cinfo2.SetTextSize(18)
	lays.readModeN.AddChild(lays.readScrlN)

	lays["readerN"] = app.CreateLayout("Linear", "Vertical,FillXY")
	//lays.reader.SetSize(-1,-1)
	lays.readScrlN.AddChild(lays.readerN)
	texts["rTextN"] = app.AddText(lays.readerN, "", 0.98, NaN, "Left,Multiline")
	texts.rTextN.SetMargins(0.01)
	texts.rTextN.SetTextSize(22)









}

//******************************LAYER 2********************************//
{
	//Title container
	btns["drawer"] = app.CreateButton("MENU", -1, -1, "")//Menu Button
	btns.drawer.SetTextSize(22)
	lays.title.AddChild(btns.drawer)
	btns.drawer.SetOnTouch(openDrawer)

	texts["title"] = app.CreateText("HOLY BIBLE", -1, -1, "Bold"); //Title text
	texts.title.SetTextSize(40)
	lays.title.AddChild(texts.title);

	/*btns["ld"]=app.CreateButton( "",-1,-1,"" )//Light dark Button
btns.ld.SetTextSize(22)
lays.title.AddChild(btns.ld)*/

	btns.drawer.SetMargins(-0.15, 0.007);
	//btns.ld.SetMargins(NaN,0.0091,-0.05)

	app.AddDrawer(lays["drawer"], "Left", 0.8)

}

{
	//drawer container
	texts["theme"] = app.AddText(lays.drawer, "THEME")
	texts.theme.SetTextSize(20)
	texts.theme.SetMargins(NaN, 0.0)
	lays["ld"] = app.CreateLayout("Linear", "Horizontal"); //light and dark theme buttons
	lays.drawer.AddChild(lays.ld);

	btns["light"] = app.CreateButton("LIGHT", -1, -1, "")//Light theme  Button
	btns.light.SetTextSize(22)
	lays.ld.AddChild(btns.light)
	btns.light.SetOnTouch()
	btns.light.SetOnTouch(lightT)


	btns["dark"] = app.CreateButton("DARK", -1, -1, "")//Light theme  Button
	btns.dark.SetTextSize(22)
	lays.ld.AddChild(btns.dark)
	btns.dark.SetOnTouch(darkT)



	//drawer list

	lays["drawlistcard"] = app.CreateLayout("card")
	lays.drawlistcard.SetCornerRadius(10);
	lays.drawlistcard.SetElevation(3)
	lays.drawer.AddChild(lays.drawlistcard);
	lays.drawlistcard.SetMargins(NaN, 0.02);

	lays["vc"] = app.CreateLayout("Linear", "VCenter")
	lays.drawlistcard.AddChild(lays.vc);

	drawerListItems = "DONATE / REMOVE ADs,HOW TO USE,PRIVACY POLICY,CONTACT US,SHARE APP,HISTORY,FAVOURITE,OLD TASTEMENT,NEW TASTEMENT,HOME"
	lists["drawer"] = app.CreateList(drawerListItems, 0.7, NaN)
	lists.drawer.SetMargins(NaN, 0.000)
	lists.drawer.SetOnTouch(drawListAction);
	lays.vc.AddChild(lists.drawer)

	drawListHeight = lays.vc.GetHeight();
	drawListHeight += 0.05;
	//lays.vc.SetSize(NaN,drawListHeight);



	//display current page
	lays["card4"] = app.CreateLayout("card")
	lays.card4.SetCornerRadius(10)
	lays.card4.SetBackColor(w)
	lays.card4.SetSize(0.7, 0.2)
	lays.card4.SetElevation(5)
	lays.card4.SetMargins(NaN, 0.05)
	lays.drawer.AddChild(lays.card4)
	lays.card4.SetVisibility(h)

	lays["pagedata"] = app.CreateLayout("Linear", "Vertical,FillXY");
	lays.card4.AddChild(lays.pagedata);

	texts["pagedata"] = app.AddText(lays.pagedata, "", 0.68, NaN, "Multiline,Left")//dusplays the current page book and chapter
	texts.pagedata.SetTextSize(20)

	texts["addfav"] = app.AddText(lays.pagedata, "\nAdd this page to favourite ", 0.68, NaN, "Left,Multiline")//adds or removre page from favouritr
	texts.addfav.SetTextColor("blue")
	texts.addfav.SetTextSize(20)
	texts.addfav.SetTouchable(true);
	texts.addfav.SetOnTouchUp(addFav)

	btns["exit"] = app.CreateButton("EXIT", 0.6, -1, "bold")//exit butto
	btns.exit.SetBackColor("red");
	btns.exit.SetTextColor(w)
	btns["exit"].SetMargins(null, 0.04);
	lays.drawer.AddChild(btns.exit)
	btns.exit.SetOnTouch(exitApp);




}


{
	//parent container

	hLays["h2"] = app.CreateLayout("Linear", "Horizontal")//holds history buttons
	lays.card2.AddChild(hLays.h2)
	btns["history"] = app.CreateButton("HISTORY", -1, -1, "")
	hLays.h2.AddChild(btns.history)
	btns.history.SetOnTouch(openHistory)

	btns["favourite"] = app.CreateButton("FAVOURITES", -1, -1, "")
	btns.favourite.SetOnTouch(openFav);
	hLays.h2.AddChild(btns.favourite)

	btns["donate"] = app.CreateButton("DONATE", -1, -1, "")
	hLays.h2.AddChild(btns.donate)

	lays["card3"] = app.CreateLayout("Card")
	tuneCard(lays["card3"]);
	lays.card3.SetSize(0.95, 0.2)
	lays.card3.SetMargins(NaN, 0.035)
	lays.parent.AddChild(lays.card3)
	hLays["h3"] = app.CreateLayout("Linear", "VCenter")
	lays.card3.AddChild(hLays.h3)

	lays["card6"] = app.CreateLayout("card"); //layout for random verse
	lays.card6.SetElevation(3);
	lays.card6.SetBackColor(w)
	lays.card6.SetMargins(NaN, 0.0135)
	lays.card6.SetCornerRadius(10)
	//lays.card6.SetSize(0.95,0.15)
	tuneCard(lays["card6"])
	lays.parent.AddChild(lays.card6);

	hLays["card6"] = app.CreateLayout("Linear", "VCenter")
	//lays.card6.SetSize(0.95,0.15)
	lays.card6.AddChild(hLays.card6)

	/*texts["card6"]=app.AddText( hLays.card6,"GENERATE RANDOM",0.95,NaN,"Bold")
texts.card6.SetTextSize(22);
*/

	lays["voc"] = app.CreateLayout("Linear", "VCenter")
	lays.voc.SetSize(0.95, 0.15)
	hLays.card6.AddChild(lays.voc);

	texts["verse"] = app.AddText(lays.voc, "GENERATE RANDOM CHAPTER", 1, NaN, "bold")
	texts.verse.SetTextSize(25)
	//texts.verse.SetMargins(0.03)


	texts["space"] = app.AddText(lays.voc, "", NaN, NaN, "bold")
	texts.space.SetTextSize(3)
	texts.space.SetTextColor("blue")

	dLine = app.CreateImage(null, 1, 0.001);
	lays.voc.AddChild(dLine);
	dLine.SetColor("blue");
	dLine.SetPaintColor("blue");
	dLine.DrawLine()


	texts["space1"] = app.AddText(lays.voc, "", NaN, NaN, "bold")
	texts.space1.SetTextSize(3)
	texts.space1.SetTextColor("blue")


	texts.verse.SetOnTouchUp(randomChap)


	texts.verse.SetTextColor("blue")

	texts["chapter"] = app.AddText(lays.voc, "GENERATE RANDOM VERSE", 1, NaN, "bold")
	texts.chapter.SetTextSize(25)
	texts.chapter.SetTextColor("blue")
	texts.chapter.SetOnTouchUp(randomVerse)
	//texts.card6.SetTextColor(b)
	//app.Alert(hLays.card6.GetParent() )

	/*	btns["randomv"] = app.CreateButton("RANDOM VERSE", 0.95, -1, "bold")
	btns.randomv.SetTextSize(30)
	hLays.h3.AddChild(btns.randomv)
	btns.randomv.SetOnTouch(randomVerse);

	btns["randomc"] = app.CreateButton("RANDOM CHAPTER", 0.95, -1, "bold")
	btns.randomc.SetTextSize(30)
	hLays.h3.AddChild(btns.randomc)
	btns.randomc.SetMargins(NaN, 0.02);
	btns.randomc.SetOnTouch(randomChap);
*/
	btns["oldT"] = app.CreateButton("OLD TASTEMENT", 0.95, -1, "bold")
	hLays.h3.AddChild(btns.oldT);
	btns.oldT.SetMargins(NaN, 0.02)
	btns.oldT.SetTextSize(30)
	btns.oldT.SetOnTouch(openOldT);


	btns["newT"] = app.CreateButton("NEW TASTEMENT", 0.95, -1, "bold")
	btns.newT.SetTextSize(30)
	btns.newT.SetMargins(NaN, 0.02)
	hLays.h3.AddChild(btns.newT)
	btns.newT.SetOnTouch(openNewT)
}

/*la=app.CreateLayout( "Absolute", "Horizontal" )
la.SetSize( 0.1,0.1 )
la.SetBackColor( "blue" )
la.SetPosition( 0.5,0.5 )
app.AddLayout( la )*/


{
	//hiatory view

	lays["history"] = mintL();
	lays.history.SetVisibility(h);
	app.AddLayout(lays.history)

	var gas = mintT(); //
	lays["titleH"] = gas[0];
	btns["titleH"] = gas[1];
	texts["titleH"] = gas[2]
	lays.history.AddChild(lays.titleH)
	//lays.history.SetBackColor("blue")

	texts["history"] = app.AddText(lays.history, "HISTORY", 0.98, NaN, "Bold")
	texts.history.SetTextSize(22)

	lays["scrlH"] = app.CreateScroller(0.98, 1);
	lays.history.AddChild(lays.scrlH);

	lays["listH"] = app.CreateLayout("Linear", "Vertical,FillXY");
	lays.scrlH.AddChild(lays.listH);
	//lays.listH.SetBackColor("blue")

	hol = 0; //history open log


}

{
	//favoiritre


	lays["favourite"] = mintL();
	lays.favourite.SetVisibility(h);
	app.AddLayout(lays.favourite)

	var gas = mintT(); //
	lays["titleF"] = gas[0];
	btns["titleF"] = gas[1];
	texts["titleF"] = gas[2]
	lays.favourite.AddChild(lays.titleF)
	//lays.history.SetBackColor("blue")

	texts["favourite"] = app.AddText(lays.favourite, "FOVOURITE", 0.98, NaN, "Bold")
	texts.favourite.SetTextSize(22)

	lays["scrlF"] = app.CreateScroller(0.98, 1);
	lays.favourite.AddChild(lays.scrlF);

	lays["listF"] = app.CreateLayout("Linear", "Vertical,FillXY");
	lays.scrlF.AddChild(lays.listF);
	//lays.listH.SetBackColor("blue")

	lists["listF"] = app.AddList(lays.listF, "", 0.98, NaN, "Expand");
	//lists.listF.SetOnTouch(




}


//floating menu
lays["floatL"] = app.CreateLayout("Absolute", "FillXY");
lays.floatL.SetTouchThrough(true);
app.AddLayout(lays.floatL)

lays["card7"] = app.CreateLayout("card");
lays.card7.SetVisibility(h)
lays.card7.SetElevation(5);
lays.card7.SetCornerRadius(40);
lays.card7.SetSize(0.45, 0.04)
lays.card7.SetBackColor(w)
lays.card7.SetPosition(0.53, 0.92)
lays.floatL.AddChild(lays.card7)

lays["floatv"] = app.CreateLayout("Linear", "VCenter,FillXY");
lays.card7.AddChild(lays.floatv);

texts["floatv"] = app.AddText(lays.floatv, "", NaN, NaN, "bold")
texts.floatv.SetTextColor("blue");
texts.floatv.SetSize(17)
texts.floatv.SetOnTouchUp(addFav);
//***********************LAYER 3************************************//

function Mode(type) {
	//ser mode to light or dark
	if (type == "light") {
		//light mode
		/*layout colors*/

		lays.home.SetBackColor(w)//home back color
		lays.title.SetBackColor("#d7d8db")//title bar color
		lays.titleO.SetBackColor("#d7d8db")//title bar color
		lays.titleN.SetBackColor("#d7d8db")//title bar color
		lays.drawer.SetBackColor(w); //drawer color
		lays.titleTO.SetBackColor("#d7d8db")
		lays.chapterO.SetBackColor(w)
		lays.readMode.SetBackColor(w)
		lays.readModeN.SetBackColor(w);
		lays.titleR.SetBackColor("#d7d8db");
		lays.titleTN.SetBackColor("#d7d8db");
		lays.titleRN.SetBackColor("#d7d8db");
		hLays.daily.SetBackColor(w)
		lays.drawlistcard.SetBackColor("#fcfcfc")
		//hLays.daily.SetBackColor("blue")



		lays.ld.SetBackColor(w)
		lays.card1.SetBackColor(w)
		lays.card2.SetBackColor(w)
		lays.card3.SetBackColor(w)

		lays.oldT.SetBackColor(w);
		lays.newT.SetBackColor(w)
		lays.chapterO.SetBackColor(w)
		lays.chapterN.SetBackColor(w);



		/*button colors*/

		btns.light.SetBackColor("#e8eaed");
		btns.light.SetTextColor(b)
		btns["dark"].SetBackColor("#e8eaed")
		btns["dark"].SetTextColor(b)

		btns.titleTO.SetTextColor(b)





		/*text colors*/
		texts.title.SetTextColor("#101112"); //Title text color
		texts.titleO.SetTextColor("#101112"); //Title text color
		texts["titleN"].SetTextColor("#101112"); //Title text color
		texts.titleTO.SetTextColor("#101112")
		texts.titleR.SetTextColor("#101112");
		texts.rText.SetTextColor("#101112");
		texts.rTextN.SetTextColor("#101112");
		texts.titleTN.SetTextColor("#101112");
		texts["titleRN"].SetTextColor("#101112");
		texts.titleD.SetBackColor("#f2f3f5")


		texts.theme.SetTextColor(b)
		lists.drawer.SetTextColor(b)
		lists.drawer.SetDivider(0.0021, b)
		lists.chapO.SetTextColor(b)
		lists.chapO.SetDivider(0.001, b)
		lists.chapN.SetDivider(0.001, b);
		lists.chapN.SetTextColor(b)


		lists.chapListO.SetTextColor(b)
		lists["chapListN"].SetTextColor(b)


		lays.titleH.SetBackColor("#d7d8db")//title bar color
		lays.history.SetBackColor(w);
		btns.titleH.SetTextColor(b)
		texts.titleH.SetTextColor("#101112"); //Title text color

		lays.titleF.SetBackColor("#d7d8db")//title bar color
		lays.favourite.SetBackColor(w);
		btns.titleF.SetTextColor(b)
		texts.titleF.SetTextColor("#101112"); //Title text color


	} else if (type == 'dark') {
		//dark mode
		/*layout colors*/

		lays.home.SetBackColor(b)//home back color
		lays.title.SetBackColor("#292a2e")//title bar color
		lays.titleO.SetBackColor("#292a2e")//title bar color
		lays.drawer.SetBackColor("#292a2e"); //drawer color
		lays.titleN.SetBackColor("#292a2e")//title bar color
		lays.ld.SetBackColor("#575759");
		lays.card1.SetBackColor("#2a2c30");
		lays.card2.SetBackColor("#2a2c30");
		lays.card3.SetBackColor("#2a2c30");
		lays["titleTO"].SetBackColor("#292a2e")
		lays.titleR.SetBackColor("#292a2e");
		lays.titleRN.SetBackColor("#292a2e");
		lays.titleTN.SetBackColor("#292a2e");
		hLays.daily.SetBackColor(w);
		lays.drawlistcard.SetBackColor("#404042");
		//hLays.daily.SetBackColor("ff8B8b8b")

		lays.oldT.SetBackColor(b)
		lays.newT.SetBackColor(b)
		lays.chapterO.SetBackColor(b)
		lays.chapterN.SetBackColor(b);
		lays.readMode.SetBackColor(b)
		lays.readModeN.SetBackColor(b)

		/*button colors*/
		btns["drawer"].SetBackColor(w);
		btns.light.SetBackColor("#292a2e");
		btns.light.SetTextColor(w);
		btns["dark"].SetBackColor("#292a2e")
		btns["dark"].SetTextColor(w)




		/*text colors*/
		texts.title.SetTextColor(w); //Title text color
		texts.titleN.SetTextColor(w); //Title text color
		texts.titleO.SetTextColor(w); //Title text color
		texts.titleTO.SetTextColor(w)
		texts.titleR.SetTextColor(w)
		texts.rText.SetTextColor(w)
		texts.rTextN.SetTextColor(w)
		texts.titleTN.SetTextColor(w)
		texts.titleRN.SetTextColor(w)
		texts.titleD.SetBackColor("#f2f3f5")
		texts.theme.SetTextColor(w)
		lists.drawer.SetTextColor(w)
		lists.drawer.SetDivider(0.0021, w)
		lists.chapO.SetTextColor(w)
		lists.chapO.SetDivider(0.001, w)
		lists.chapN.SetDivider(0.001, w);
		lists.chapN.SetTextColor(w)


		lists.chapListO.SetTextColor(w);
		lists.chapListN.SetTextColor(w);


		lays.titleH.SetBackColor("#292a2e")//title bar color
		lays.history.SetBackColor(b);
		btns.titleH.SetTextColor(b)
		texts.titleH.SetTextColor(w); //Title text color


		lays.titleF.SetBackColor("#292a2e")//title bar color
		lays.favourite.SetBackColor(b);
		btns.titleF.SetTextColor(b)
		texts.titleF.SetTextColor(w); //Title text color



	}
}


function setMode(type) {
	//store dark of light mode
	app.SaveText("mode", type, lightdark)

	var currentMode = app.LoadText("mode", "light", lightdark);
	Mode(currentMode);
	app.ShowPopup(`${currentMode} mode`)
}


function darkT() {
	setMode("dark")
}

function lightT() {
	setMode("light")
}

//open functions
parentLays = ["home", "oldT", "newT", "chapterO", "chapterN", "readMode", "readModeN", "history", "favourite"]; //parent layouts

function drawListAction(name) {
	//drawer list action

	lays.card4.SetVisibility(h)

	var opcount = openLays.length
	if (name == "HOME" && status !== "home") {
		closeLays();
		while (openLays[opcount-1] != "home") {
			//clear back key cache
			openLays.pop();
			opcount--

		}

		status = "home";

	} else if (name == "NEW TASTEMENT" && status !== "newT") {
		openNewT();
	} else if (name == "OLD TASTEMENT" && status !== "oldT") {
		openOldT();
	} else if (name == "HISTORY" && status !== "history") {
		openHistory();
	}



	if (name !== "")app.CloseDrawer("left")//close drawer

}

function exitApp() {
	//Exit app function
	let response = app.CreateYesNoDialog("Are you sure to exit the app?")
	response.Show()
	response.SetOnTouch(response_OnTouch);
}

function response_OnTouch(reply) {
	//close app
	if (reply == "Yes") {
		app.Exit();
	}
}


function tuneCard(card) {
	card.SetElevation(20);
	card.SetCornerRadius(10);
	card.SetMargins(null, 0.01)
}
//open functions
function openDrawer() {
	app.OpenDrawer("left");
}



function openOldT() {
	//open old tastement
	closeLays();
	lays.scrlO.ScrollTo(0)
	lays.oldT.SetVisibility(s);
	lays.oldT.Animate("SlideFromLeft")
	status = "oldT";
	addOpenLay(status)
}

function openNewT() {
	//open new tastement
	closeLays();
	lays.newT.SetVisibility(s);
	lays.newT.Animate("SlideFromLeft")
	status = "newT"
	addOpenLay(status);
}

function openO(name) {
	//shows list of chapters for old tastement
	closeLays();
	lists.chapListO.RemoveAll(); //remove all items from the list
	gName = name;
	texts.cinfo1O.SetText(gName);

	lays.chapterO.SetVisibility(s);
	lays.chapterO.Animate("SlideFromBottom")
	status = "chapterO"
	addOpenLay(status);

	let cl = chapterMap[name];
	cl = parseInt(cl)
	let ncl = cl+1;

	//app.ShowPopup( ncl )
	for (let ij = 1; ij < ncl; ij++) {
		//app.ShowPopup( ij )
		lists.chapListO.AddItem(`CHAPTER ${ij}`)
	}



	//app.ShowPopup( ncl )
}


function openN(name) {

	closeLays();
	lists.chapListN.RemoveAll(); //remove all items from the list
	gName = name; //global name

	texts.cinfo1.SetText(gName)
	lays.chapterN.SetVisibility(s);
	lays.chapterN.Animate("SlideFromBottom")
	status = "chapterN"
	addOpenLay(status);

	let cl = chapterMapN[name];
	cl = parseInt(cl)
	let ncl = cl+1;

	//app.ShowPopup( ncl )
	for (let ij = 1; ij < ncl; ij++) {
		//app.ShowPopup( ij )
		lists.chapListN.AddItem(`CHAPTER ${ij}`)

	}


}


function openFav() {
	//open favourite
	//jdb["favourite"]=[];

	lists.listF.RemoveAll();

	closeLays();
	lays.favourite.SetVisibility(s);
	lays.favourite.Animate("SlideFromLeft")
	status = "favourite"
	addOpenLay(status);
	var pl = jdb["favourite"];
	//app.Alert( pl )


	for (var item of pl) {

		lists.listF.AddItem(item);

	}

}


function addFav() {
	//add favourite and clear history

	//add to favourite database
	var indh; //index of hLog;

	jdb.favourite.includes(hLog)?indh = jdb.favourite.indexOf(hLog): false;
	const rItem = jdb.favourite; // tempoary item

	indh+1?rItem.splice(indh, 1): true;
	rItem.unshift(hLog);


	writeDB("favourite", rItem)

	//app.Alert( jdb.favourite )

}


function openHistory() {
	//add history
	hol++;
	hol > 0?lays.listH.DestroyChild(lists.history): false;
	//lists.history.RemoveAll();//clear list
	lays.history.SetVisibility(s); //show history

	const rList = jdb.history

	const joinList = rList.join();

	lists["history"] = app.AddList(lays.listH, joinList, 0.98, NaN, "Expand")//list to display history
	lists.history.SetOnTouch(openH)
	const lh = lists.history.GetHeight();
	lists.history.SetSize(NaN, lh+0.2); //adjust list height

	status = "history"; //update stataus
	addOpenLay(status);

	/*for (let i=0;i<jdb.history.length;i++){
lists.history.AddItem(jdb.history[i]);//add list
}
*/



	lays.history.AddChild(lists.history);

	/*const lenList=lists.history.GetHeight();
app.ShowPopup( lenList )
lays.listH.SetSize(NaN,lenList);
*/

}


const count = (string, item)=> {
	return (string.split(`${item}`).length)-1;
}



function openH(fl) {
	var book,
	chap;

	if (count(fl, " ") == 2) {
		//if there is only two space
		//console.log (2)
		const indos = fl. indexOf(" ");
		book = fl. substr(0, indos);

		//	console.log([book])
	} else if (count(fl, " ") == 3) {
		//if there is more than one space
		//console.log (3)

		const indos = fl. indexOf(" ");
		book = fl. substr(0, fl. indexOf(" ", indos+1));


		//console.log ([book])
	}

	var chap = fl. indexOf("CHAPTER");
	chap = fl. substr(chap);
	//console.log ([book, chap])

	gName = book; //set global name
	if (booksO.includes(book)) {
		//app.Alert( booksO )
		readMode(chap);

	} else if (booksN.includes(gName)) {
		//	app.Alert( booksN )
		readModeN(chap);

	}


}










const addHistory = ()=> {
	//add to history database
	var indh; //index of hLog;

	jdb.history.includes(hLog)?indh = jdb.history.indexOf(hLog): false;
	const rItem = jdb.history; // tempoary item

	indh+1?rItem.splice(indh, 1): true;
	rItem.unshift(hLog);


	writeDB("history", rItem)
}





function readMode(name) {

	//texts.pagedata.SetText("");

	texts.rText.SetSize(0.98, null)
	lays.readScrl.ScrollTo(0)
	texts.rText.SetText("")
	var ind = name.indexOf(" "); // index of space
	var req = name.substr(ind+1, name.length)
	var chapp = parseInt(req);
	var chapp = chapp-1;
	var page = bibleO[gName][chapp]


	closeLays();
	lays.readMode.SetVisibility(s);
	lays.readMode.Animate("SlideFromLeft")
	status = "readMode"
	addOpenLay(status);

	texts.rText.SetText(page)
	hLog = `${gName} CHAPTER ${chapp+1}`//set history log
	texts.cinfo2O.SetText(hLog);
	addHistory();
	texts.pagedata.SetText(`You are currently reading\n${gName}\nChapter ${chapp+1}`);
	//lays.card4.SetVisibility(s); //display page data info
	lays.card7.SetVisibility(s)

	//var lh=texts.rText.GetHeight();
	//texts.rText.SetSize(0.98,lh+0.1)
	//app.ShowPopup( lays.reader.GetHeight())
}

//app.Alert( Object.keys(bibleN) )


function readModeN(name) {
	//read mode for new tastement
	texts.rTextN.SetSize(0.98, null)
	lays.readScrlN.ScrollTo(0)
	texts.rTextN.SetText("")
	var ind = name.indexOf(" "); // index of space
	var req = name.substr(ind+1, name.length)
	var chapp = parseInt(req);
	var chapp = chapp-1;
	page = bibleN[gName][chapp];
	//app.ShowPopup(page.length)

	//app.ShowPopup( gName )
	closeLays();
	lays.readModeN.SetVisibility(s);
	lays.readModeN.Animate("SlideFromLeft")
	status = "readModeN"
	addOpenLay(status);

	texts.rTextN.SetText(page)

	hLog = `${gName} CHAPTER ${chapp+1}`//set history log

	texts.cinfo2.SetText(hLog)

	//app.ShowPopup( hLog )
	addHistory();

	texts.pagedata.SetText(`You are currently reading\n${gName}\nChapter ${chapp+1}`);
	lays.card4.SetVisibility(s)//display page data layout


	lays.card7.SetVisibility(s)

	//texts.rTextN.SetTextColor("Blue")
	//app.Alert( texts.rTextN)
	//var lh=texts.rTextN.GetHeight();
	//app.ShowPopup( lh )
	//texts.rText.SetSize(0.98,lh+0.1)
	//app.ShowPopup( lays.reader.GetHeight())
}



function randomChap() {
	//generate random chaptere
	var cbookj;
	const booklist = [booksO,
		booksN]; //books list
	const rb = pickRandom(booklist); //seletct random list

	if (rb == booksO) {
		//app.ShowPopup( 1 )
		cbookj = bibleO;

	} else {
		//app.ShowPopup( 2 )
		cbookj = bibleN;

	}

	const bk = pickRandom(rb); //random book
	const cbook = cbookj[bk]; //choose from object
	const rchap = pickRandom(cbook); //random chapter
	//app.ShowPopup( rchap.length)

	app.Alert(rchap, `${bk}: ${cbook.indexOf(rchap)+1}`)
}


function randomVerse() {
	// random verses

	var cbookj;
	const booklist = [booksO,
		booksN]; //books list
	const rb = pickRandom(booklist); //seletct random list

	if (rb == booksO) {
		//app.ShowPopup( 1 )
		cbookj = bibleO;

	} else {
		//app.ShowPopup( 2 )
		cbookj = bibleN;

	}

	const bk = pickRandom(rb); //random book
	const cbook = cbookj[bk]; //choose from object
	const rchap = pickRandom(cbook); //random chapter
	//app.ShowPopup( rchap.length)

	//~~~~~~~~~~~~~~~~~~~~~~~~~~~//

	const chap = 1+cbook.indexOf(rchap);
	const irange = [176,
		70,
		20,
		2]; //index range
	var verse,
	por,
	returnValue;

	for (var num of irange) {
		verse = pickRandom(num); //pick random verse
		verse++;
		por = `${chap}:${verse}` //random portion
		ind = rchap.indexOf(por)
		if (ind!==-1) {
			break;
		}
	}

	const stop = `${chap}:${verse+1}`; //stop value
	const sp = rchap.indexOf(stop); //stop index
	sp!==-1?returnValue = rchap.substring(ind, sp): returnValue = rchap.substring(ind);


	returnValue = returnValue.replace("\n".repeat(5), "")

	app.Alert(returnValue, `${bk}   ${cbook.indexOf(rchap)+1}:${verse}`)



}

const dailyRead = ()=> {

	const lastDate = jdb.daily

	const d = new Date(); //date object
	const m = d.getDate()
	writeDB("daily", m); //write last minute to file;


	if (lastDate !== jdb.daily) {


		var cbookj;
		const booklist = [booksO,
			booksN]; //books list
		const rb = pickRandom(booklist); //seletct random list

		if (rb == booksO) {
			//app.ShowPopup( 1 )
			cbookj = bibleO;

		} else {
			//app.ShowPopup( 2 )
			cbookj = bibleN;

		}

		const bk = pickRandom(rb); //random book
		const cbook = cbookj[bk]; //choose from object
		const rchap = pickRandom(cbook); //random chapter
		//app.ShowPopup( rchap.length)

		texts.daily.SetText(rchap)

		var txtt = texts.titleD.GetText()
		txtt = `${txtt} -  ${bk}: ${cbook.indexOf(rchap)+1}`;
		texts.titleD.SetText(txtt)

		writeDB("lastread", rchap);
		//var titl=`${txtt} -  ${bk}: ${cbook.indexOf(rchap)+1}`
		writeDB("lasttitle", txtt);

		//app.Alert(lastMinute)
	} else {

		texts.daily.SetText(jdb.lastread)
		//app.Alert( jdb.lasttitle )
		texts.titleD.SetText(jdb.lasttitle)
	}


}


function openD() {
	//expand daily readin
	const privateN = jdb.lasttitle;

	const txt = privateN;
	const st = txt.indexOf("- "); //start
	const sp = txt.indexOf(":"); //stop
	const name = txt. slice(st+3, sp); //global name
	const chap = `CHAPTER ${txt. slice(sp+1)}`
	gName = name;

	//app.Alert( gName.length)

	if (booksO.includes(name)) {
		//app.Alert( "old" )

		readMode(chap);

	} else if (booksN.includes(name)) {
		//app.Alert( "new" )

		readModeN(chap);


	}



}




const closeLays = ()=> {
	//close all layouts
	for (let i = 1; i < parentLays.length; i++) {
		lays[parentLays[i]].SetVisibility(h)
	}

}

const addOpenLay = (laystr)=> {
	//adds item to open array
	ind = openLays.indexOf(laystr); //cheek if lay is already in the layout
	if (ind===-1) {
		openLays.push(laystr)
	} else {
		openLays.splice(ind, 1)
		openLays.push(laystr);
	}
}



const OnBack = ()=> {
	//back key function

	if (app.GetDrawerState("left") == "Open") {
		//cheek if drawer is open
		app.CloseDrawer("left")
		return 0;
	}

	if (status == "home" /*&& app.GetDrawerState("right")=="Closed"*/) {
		exitApp();
	} else {

		lays.card4.SetVisibility(h);

		closeLays();
		lastIndex = openLays.length-2
		if (lastIndex == 0) {
			closeLays();
			openLays.pop();
			status = "home";
		} else {

			lays[openLays[lastIndex+1]].SetVisibility(h);
			openLays.pop();
			lays[openLays[lastIndex]].SetVisibility(s);
			status = openLays[lastIndex];

		}
	}
}
console.log(3)


function mintL() {
	//mint vertical parent layout
	let nlay = app.CreateLayout("Linear", "Vertical,FillXY");
	//nlay.SetBackColor("blue")
	return nlay
}

function mintT() {
	var tlay = app.CreateLayout("Linear", "Horizontal,FillX")//title bar layout
	tlay.SetSize(-1, -1)

	var btn = app.CreateButton("MENU", -1, -1, "")//Menu Button
	btn.SetTextSize(22)
	tlay.AddChild(btn)
	btn.SetMargins(-0.15, 0.01)
	btn.SetOnTouch(openDrawer)

	var text = app.CreateText("HOLY BIBLE", -1, -1, "Bold"); //Title text
	text.SetTextSize(40);
	tlay.AddChild(text);



	return [tlay,
		btn,
		text]
}



const pickRandom = (list, num)=> {
	const tlist = typeof(list);
	const tnum = typeof(num);
	//console.log (typeof(list))

	const bollist = tlist === "object";
	const bolmin = tlist === "number";
	const bolmax = tnum == "number";
	//console.log (tlist)



	if (bollist) {
		const l = list.length; //length of array
		const r = Math.random(); //random number
		const p = r*100;
		const fp = Math.floor(p); //percentage
		const pofl = (fp/100)*l; //array percent
		const pick = Math.floor(pofl); //random index
		//console.log (pick);
		return list[pick]; //return random item

	} else if (bolmin && bolmax) {
		//min max
		var val = list-num;

		if (val < 0) {
			val = val*(-1);
			const r = Math.random();
			const rpm = (r*val)+list;
			return Math.floor(rpm);
		} else {

			const r = Math.random();
			const rpm = (r*val)+num;
			return Math.floor(rpm);


		}
	} else if (bolmin) {
		//one number

		const r = Math.random(); //random number
		const rpm = (r)*list;
		return Math.floor(rpm);
	}
}


//Called when application is started.
OnStart = ()=> {
	status = "home";

	Mode(app.LoadText("mode", "light", lightdark))//set mode to light mode

	db = app.LoadText("adb", "{}", dbf)//cheek if database is empty
	if (db == "{}") {
		jdb = JSON.parse(db); //convert saved text to json object.
		//create data keys
		jdb["times"] = 1;
		jdb["daily"] = [];
		jdb["history"] = [];
		jdb["favourite"] = [];
		db = JSON.stringify(jdb)
		app.SaveText("adb", db, dbf)//save data
	} else {
		jdb = JSON.parse(db); //convert saved text to json object.
		//update data key values
		jdb["times"]++; //incrrment number of times open
		//	jdb["favourite"]=[];
		db = JSON.stringify(jdb)
		app.SaveText("adb", db, dbf)//save data
	}

	dailyRead();
	//writeDB("history",[]);
	/*
var gk=Object.keys(jdb);

app.Alert( gk )
*/


}

const writeDB = (key, value)=> {
	//write database
	jdb[key] = value;

	db = JSON.stringify(jdb)

	app.SaveText("adb", db, dbf)//save data



}


//writeDB("favourite",[])





function OnError(msg, line, file) {
	var txtt = `\n\nMESSAGE: ${msg}\n\nLINE: ${line}\n\nFILE: ${file} `;

	app.Alert(txtt, "Please screenshot this mesaage and send to the developer:")



}




lays["home"].DestroyChild(loadLay); //destroy loading view
//lays.home.Animate("FlipFromBottom");
