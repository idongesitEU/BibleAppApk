function snippet() {
	mode = {}//return object
	state.push(lay);

	const homeLay = app.CreateLayout("Linear",
		"Vertical,FillXY");
	app.AddLayout(homeLay);


	const title = app.CreateLayout("Linear",
		"Horizontal,FillX") //title bar layout
	title.SetSize(1, -1);
	homeLay.AddChild(title);

	var menu = app.CreateButton("  MENU  ", -1, -1, "") //Menu Button

	menu.SetTextSize(22)
	title.AddChild(menu)
	menu.SetMargins(-0.150, 0.01, 0.01, 0.01)
	menu.SetOnTouch(openDrawer)

	const titleText = app.AddText(title, "HOLY BIBLE", -1, -1,
		"bold");
	titleText.SetTextSize(40)

const logText=app.AddText( homeLay,hLog,1,NaN,"bold" )
logText.SetTextSize(18)
logText.SetBackColor( "#ededed" )


	const scrl = app.AddScroller(homeLay, 1, 0.97);

	const scrlPad = app.CreateLayout("Linear", "Vertical,FillXY");
	scrl.AddChild(scrlPad);

/*code goes here */




	//++
	const setMode = () => {
		//set mode foe old testament

		if (ldb.mode == "light") {
			menu.SetStyle(w, w, 3, w, 3, 10)
			menu.SetTextColor("black")
			homeLay.SetBackColor("white")
			titleText.SetTextColor("black");
			title.SetBackColor("#f0f2f5")

		} else if (ldb.mode == "dark") {

			menu.SetStyle(btnb, btnb, 3, btnb, 3, 10);
			homeLay.SetBackColor(b);
			menu.SetBackColor(btnb);
			menu.SetTextColor("white");
			titleText.SetTextColor("white");
			title.SetBackColor(lb)


		}

	}

	setMode();
	mode["setMode"] = setMode;

	//++

	const destroy = () => {
		app.DestroyLayout(homeLay)

	}
	mode["destroy"] = destroy;

	openLays.push(mode);

}
